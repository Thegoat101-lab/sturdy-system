import { redirect } from "next/navigation"
import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark } from "lucide-react"
import Link from "next/link"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default async function ContentPage({ params }: { params: { id: string } }) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  // Mock content data - in a real app, this would be fetched based on the ID
  const content = {
    id: params.id,
    title: "Tutorial: Advanced Editing Techniques",
    type: "video",
    videoUrl: "/placeholder.svg?height=720&width=1280", // In a real app, this would be a real video URL
    description:
      "Learn advanced video editing techniques from a professional editor. This tutorial covers color grading, transitions, effects, and more.",
    creator: {
      name: "Pro Editor",
      username: "proeditor",
      avatar: "/placeholder.svg?height=40&width=40",
      isVerified: true,
      subscribers: 125000,
    },
    stats: {
      views: 45280,
      likes: 3621,
      comments: 128,
    },
    publishedAt: "2 weeks ago",
    tags: ["tutorial", "editing", "video"],
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-6xl p-4">
        <Button
          variant="ghost"
          className="mb-4 flex items-center gap-2 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          asChild
        >
          <Link href="/premium">
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Premium Content</span>
          </Link>
        </Button>

        <div className="overflow-hidden rounded-lg bg-black">
          <div className="aspect-video w-full">
            {/* This would be a video player in a real app */}
            <img
              src={content.videoUrl || "/placeholder.svg"}
              alt={content.title}
              className="h-full w-full object-cover"
            />
            <div className="flex items-center justify-center">
              <svg className="h-24 w-24 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="mt-4 space-y-6">
          <div>
            <h1 className="text-2xl font-bold sm:text-3xl">{content.title}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-4">
              <span className="text-gray-600 dark:text-gray-400">{content.stats.views.toLocaleString()} views</span>
              <span className="text-gray-600 dark:text-gray-400">{content.publishedAt}</span>
              <div className="flex flex-wrap gap-2">
                {content.tags.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 rounded-lg bg-white/80 p-4 backdrop-blur-sm dark:bg-gray-900/80">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center gap-1 hover:bg-brand-purple/10 hover:text-brand-purple dark:hover:bg-brand-pink/10 dark:hover:text-brand-pink"
              >
                <Heart className="h-5 w-5" />
                <span>{content.stats.likes.toLocaleString()}</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center gap-1 hover:bg-brand-purple/10 hover:text-brand-purple dark:hover:bg-brand-pink/10 dark:hover:text-brand-pink"
              >
                <MessageCircle className="h-5 w-5" />
                <span>{content.stats.comments.toLocaleString()}</span>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="flex items-center gap-1 hover:bg-brand-purple/10 hover:text-brand-purple dark:hover:bg-brand-pink/10 dark:hover:text-brand-pink"
              >
                <Share2 className="h-5 w-5" />
                <span>Share</span>
              </Button>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center gap-1 hover:bg-brand-purple/10 hover:text-brand-purple dark:hover:bg-brand-pink/10 dark:hover:text-brand-pink"
            >
              <Bookmark className="h-5 w-5" />
              <span>Save</span>
            </Button>
          </div>

          <div className="rounded-lg bg-white/80 p-4 backdrop-blur-sm dark:bg-gray-900/80">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <Avatar className="h-12 w-12 border-2 border-brand-pink">
                  <AvatarImage src={content.creator.avatar} alt={content.creator.name} />
                  <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                    {content.creator.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{content.creator.name}</h3>
                    {content.creator.isVerified && (
                      <svg
                        className="h-4 w-4 text-brand-purple dark:text-brand-pink"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                      >
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                      </svg>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">@{content.creator.username}</p>
                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
                    {content.creator.subscribers.toLocaleString()} subscribers
                  </p>
                </div>
              </div>
              <Button className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple">
                Subscribe
              </Button>
            </div>
            <div className="mt-4">
              <p className="whitespace-pre-wrap text-gray-700 dark:text-gray-300">{content.description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

