"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, CreditCard, Loader2 } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { purchaseContent } from "@/lib/content-actions"

export default function PurchaseContentPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [isProcessing, setIsProcessing] = useState(false)

  // Mock content data - in a real app, this would be fetched based on the ID
  const content = {
    id: params.id,
    title: "Tutorial: Advanced Editing Techniques",
    type: "video",
    thumbnail: "/placeholder.svg?height=720&width=1280",
    creator: {
      name: "Pro Editor",
      username: "proeditor",
    },
    price: "4.99",
  }

  const handlePurchase = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    try {
      // In a real app, this would process the payment
      await purchaseContent(content.id)

      // Redirect to the content page
      router.push(`/content/${content.id}`)
    } catch (error) {
      console.error("Failed to process payment:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <div className="container mx-auto flex max-w-4xl flex-1 items-center justify-center p-4">
        <div className="w-full">
          <Button
            variant="ghost"
            className="mb-6 flex items-center gap-2 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
            asChild
          >
            <Link href={`/premium`}>
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Premium Content</span>
            </Link>
          </Button>

          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <div className="relative overflow-hidden rounded-lg">
                <img
                  src={content.thumbnail || "/placeholder.svg"}
                  alt={content.title}
                  className="aspect-video w-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
                  <h2 className="text-xl font-bold">{content.title}</h2>
                  <p className="text-sm">By @{content.creator.username}</p>
                </div>
              </div>

              <div className="mt-4 rounded-lg bg-white/80 p-4 backdrop-blur-sm dark:bg-gray-900/80">
                <h3 className="font-medium">Purchase Details</h3>
                <div className="mt-2 flex items-center justify-between">
                  <span>Content Price</span>
                  <span>${content.price}</span>
                </div>
                <div className="mt-1 flex items-center justify-between">
                  <span>Processing Fee</span>
                  <span>$0.50</span>
                </div>
                <div className="mt-2 border-t pt-2">
                  <div className="flex items-center justify-between font-medium">
                    <span>Total</span>
                    <span>${(Number.parseFloat(content.price) + 0.5).toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 text-center text-sm text-gray-600 dark:text-gray-400">
                <p>
                  Consider{" "}
                  <Link
                    href="/membership"
                    className="text-brand-purple underline hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
                  >
                    becoming a member
                  </Link>{" "}
                  to access all premium content.
                </p>
              </div>
            </div>

            <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
              <CardHeader>
                <CardTitle>Payment Information</CardTitle>
                <CardDescription>Enter your payment details to purchase this content</CardDescription>
              </CardHeader>
              <form onSubmit={handlePurchase}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name on Card</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      required
                      className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="card">Card Number</Label>
                    <div className="relative">
                      <Input
                        id="card"
                        placeholder="1234 5678 9012 3456"
                        required
                        className="border-purple-200 bg-white/80 pl-10 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                      />
                      <CreditCard className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiry">Expiry Date</Label>
                      <Input
                        id="expiry"
                        placeholder="MM/YY"
                        required
                        className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cvc">CVC</Label>
                      <Input
                        id="cvc"
                        placeholder="123"
                        required
                        className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                      </>
                    ) : (
                      `Pay $${(Number.parseFloat(content.price) + 0.5).toFixed(2)}`
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

