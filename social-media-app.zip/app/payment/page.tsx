import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { PaymentProcessor } from "@/components/payment/payment-processor"

export default async function PaymentPage({
  searchParams,
}: {
  searchParams: {
    type?: string
    planId?: string
    contentId?: string
    amount?: string
    returnUrl?: string
  }
}) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  const { type = "subscription", planId, contentId, amount, returnUrl = "/" } = searchParams

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-md p-4">
        <h1 className="mb-6 bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">
          {type === "subscription" ? "Subscribe" : "Purchase Content"}
        </h1>
        <PaymentProcessor
          type={type as "subscription" | "content"}
          planId={planId}
          contentId={contentId}
          amount={amount}
          returnUrl={returnUrl}
        />
      </div>
    </div>
  )
}

