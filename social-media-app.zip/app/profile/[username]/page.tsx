import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { ProfileHeader } from "@/components/profile/profile-header"
import { ProfileTabs } from "@/components/profile/profile-tabs"

export default async function ProfilePage({ params }: { params: { username: string } }) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  // In a real app, you would fetch the user data based on the username
  const user = {
    id: "1",
    username: params.username,
    name: "User Name",
    bio: "This is a bio description for the user profile.",
    avatar: "/placeholder.svg?height=150&width=150",
    followers: 1250,
    following: 420,
    posts: 86,
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto p-4">
        <ProfileHeader user={user} />
        <ProfileTabs username={params.username} />
      </div>
    </div>
  )
}

