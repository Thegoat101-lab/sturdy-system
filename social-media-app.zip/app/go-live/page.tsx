import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { GoLiveForm } from "@/components/live/go-live-form"

export default async function GoLivePage() {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-4xl p-4">
        <h1 className="mb-6 bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">Start Live Stream</h1>
        <GoLiveForm />
      </div>
    </div>
  )
}

