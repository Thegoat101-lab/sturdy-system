import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { MembershipPlans } from "@/components/membership/membership-plans"

export default async function MembershipPage() {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-5xl p-4 py-8">
        <MembershipPlans />
      </div>
    </div>
  )
}

