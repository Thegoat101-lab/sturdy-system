import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { VideoUploadForm } from "@/components/video-upload-form"

export default async function UploadPage() {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-3xl p-4">
        <h1 className="mb-6 bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">Upload New Video</h1>
        <VideoUploadForm />
      </div>
    </div>
  )
}

