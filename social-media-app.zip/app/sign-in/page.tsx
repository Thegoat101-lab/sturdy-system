import Link from "next/link"
import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { SignInForm } from "@/components/auth/sign-in-form"

export default async function SignInPage() {
  const session = await auth()

  if (session) {
    redirect("/")
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-purple-100 via-pink-50 to-blue-100 px-4 py-8 dark:from-purple-950 dark:via-gray-900 dark:to-blue-950 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="bg-gradient-brand bg-clip-text text-4xl font-extrabold tracking-tight text-transparent">
            Welcome back
          </h1>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">Sign in to your account to continue</p>
        </div>
        <div className="mt-8">
          <SignInForm />
          <div className="mt-6 text-center text-sm">
            <p className="text-gray-600 dark:text-gray-400">
              Don&apos;t have an account?{" "}
              <Link
                href="/sign-up"
                className="font-medium text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
              >
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

