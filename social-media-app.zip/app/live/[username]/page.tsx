import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { StreamPlayer } from "@/components/live/stream-player"
import { StreamChat } from "@/components/live/stream-chat"
import { ChannelInfo } from "@/components/live/channel-info"

export default async function ChannelPage({ params }: { params: { username: string } }) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  // In a real app, you would fetch the channel and stream data based on the username
  const channel = {
    id: "channel_1",
    username: params.username,
    name: params.username.charAt(0).toUpperCase() + params.username.slice(1),
    avatar: "/placeholder.svg?height=150&width=150",
    isLive: true,
    title: "Gaming session with viewers! Come hang out!",
    category: "Gaming",
    viewers: 1245,
    followers: 45600,
    description:
      "Welcome to my channel! I stream games, do creative content, and just hang out with my amazing community.",
    tags: ["gaming", "fps", "multiplayer"],
    subscriberCount: 28500,
    isSubscribed: false,
    isBellOn: false,
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto p-4">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <StreamPlayer channel={channel} />
            <ChannelInfo channel={channel} />
          </div>
          <div className="lg:col-span-1">
            <StreamChat channelName={channel.name} />
          </div>
        </div>
      </div>
    </div>
  )
}

