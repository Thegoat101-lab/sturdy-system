import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { CallInterface } from "@/components/call/call-interface"

export default async function CallPage({
  params,
  searchParams,
}: {
  params: { id: string }
  searchParams: { type?: string }
}) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  const callType = searchParams.type === "video" ? "video" : "audio"

  return <CallInterface friendId={params.id} callType={callType} />
}

