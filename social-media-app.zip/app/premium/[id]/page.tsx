import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { PremiumContent } from "@/components/membership/premium-content"
import { SideNav } from "@/components/side-nav"
import { getPremiumContent } from "@/lib/membership-actions"

export default async function PremiumContentPage({ params }: { params: { id: string } }) {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  // In a real app, you would fetch the premium content based on the ID
  const content = await getPremiumContent(params.id)

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto grid grid-cols-1 gap-4 p-4 md:grid-cols-4">
        <div className="hidden md:col-span-1 md:block">
          <SideNav />
        </div>
        <div className="col-span-1 md:col-span-3">
          <PremiumContent content={content} />
        </div>
      </div>
    </div>
  )
}

