import { redirect } from "next/navigation"

import { auth } from "@/lib/auth"
import { TopNav } from "@/components/top-nav"
import { ContactsManager } from "@/components/contacts/contacts-manager"

export default async function ContactsPage() {
  const session = await auth()

  if (!session) {
    redirect("/sign-in")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <TopNav />
      <div className="container mx-auto max-w-4xl p-4">
        <h1 className="mb-6 bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">Manage Contacts</h1>
        <ContactsManager />
      </div>
    </div>
  )
}

