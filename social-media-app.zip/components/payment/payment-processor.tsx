"use client"

import type React from "react"
\
```tsx file="components/payment/payment-processor.tsx"
"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { CreditCard, Check, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from "@/hooks/use-toast"
import { processPayment } from "@/lib/payment-actions"

interface PaymentProcessorProps {
  type: "subscription" | "content"
  planId?: string
  contentId?: string
  amount?: string
  returnUrl: string
}

export function PaymentProcessor({ type, planId, contentId, amount, returnUrl }: PaymentProcessorProps) {
  const router = useRouter()
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<"credit-card" | "paypal">("credit-card")
  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    cardholderName: "",
    expiryDate: "",
    cvv: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target

    // Format card number with spaces
    if (name === "cardNumber") {
      const formatted = value
        .replace(/\s/g, "")
        .replace(/(\d{4})/g, "$1 ")
        .trim()
      setCardDetails({ ...cardDetails, [name]: formatted })
      return
    }

    // Format expiry date with slash
    if (name === "expiryDate") {
      const cleaned = value.replace(/\D/g, "")
      let formatted = cleaned
      if (cleaned.length > 2) {
        formatted = `${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`
      }
      setCardDetails({ ...cardDetails, [name]: formatted })
      return
    }

    setCardDetails({ ...cardDetails, [name]: value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    try {
      // In a real app, you would validate the card details and process the payment
      const result = await processPayment({
        type,
        planId,
        contentId,
        amount,
        paymentMethod,
        cardDetails: paymentMethod === "credit-card" ? cardDetails : undefined,
      })

      toast({
        title: "Payment successful",
        description: type === "subscription" ? "Your subscription has been activated" : "Your purchase was successful",
      })

      // Redirect to the return URL
      setTimeout(() => {
        router.push(returnUrl)
      }, 1500)
    } catch (error) {
      toast({
        title: "Payment failed",
        description: "Please check your payment details and try again",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  // Determine payment amount and description
  const paymentAmount = amount || (type === "subscription" ? "$9.99/month" : "$4.99")
  const paymentDescription =
    type === "subscription" ? "You're subscribing to the premium plan" : "You're purchasing premium content"

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
        <CardTitle>Payment Details</CardTitle>
        <CardDescription className="text-white/80">{paymentDescription}</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6 flex items-center justify-between rounded-lg bg-gray-50 p-4 dark:bg-gray-800">
          <div>
            <p className="font-medium">Total Amount</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {type === "subscription" ? "Recurring payment" : "One-time payment"}
            </p>
          </div>
          <p className="text-2xl font-bold">{paymentAmount}</p>
        </div>

        <form onSubmit={handleSubmit}>
          <RadioGroup
            defaultValue="credit-card"
            className="mb-6"
            value={paymentMethod}
            onValueChange={(value) => setPaymentMethod(value as "credit-card" | "paypal")}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="credit-card" id="credit-card" />
              <Label htmlFor="credit-card" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                Credit Card
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="paypal" id="paypal" />
              <Label htmlFor="paypal">PayPal</Label>
            </div>
          </RadioGroup>

          {paymentMethod === "credit-card" ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input
                  id="cardNumber"
                  name="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardDetails.cardNumber}
                  onChange={handleInputChange}
                  maxLength={19}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cardholderName">Cardholder Name</Label>
                <Input
                  id="cardholderName"
                  name="cardholderName"
                  placeholder="John Doe"
                  value={cardDetails.cardholderName}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiryDate">Expiry Date</Label>
                  <Input
                    id="expiryDate"
                    name="expiryDate"
                    placeholder="MM/YY"
                    value={cardDetails.expiryDate}
                    onChange={handleInputChange}
                    maxLength={5}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input
                    id="cvv"
                    name="cvv"
                    placeholder="123"
                    value={cardDetails.cvv}
                    onChange={handleInputChange}
                    maxLength={4}
                    required
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-lg border border-dashed p-6 text-center">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                You will be redirected to PayPal to complete your payment
              </p>
            </div>
          )}

          <Button
            type="submit"
            className="mt-6 w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
            disabled={isProcessing}
          >
            {isProcessing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Check className="mr-2 h-4 w-4" />
                {type === "subscription" ? "Subscribe Now" : "Complete Purchase"}
              </>
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="bg-gray-50 px-6 py-4 text-center text-sm text-gray-500 dark:bg-gray-800/50 dark:text-gray-400">
        Your payment information is secure and encrypted
      </CardFooter>
    </Card>
  )
}

