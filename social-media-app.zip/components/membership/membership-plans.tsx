"use client"

import { useState } from "react"
import { Check, Crown, Sparkles, Star, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { subscribeToPlan } from "@/lib/membership-actions"

export function MembershipPlans() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const plans = [
    {
      id: "basic",
      name: "Basic",
      price: "$4.99",
      period: "month",
      description: "Access to exclusive posts and content",
      features: ["Access to premium posts", "Ad-free experience", "Early access to public content"],
      icon: Star,
      color: "text-blue-500",
      bgColor: "bg-blue-100 dark:bg-blue-900/20",
      borderColor: "border-blue-200 dark:border-blue-800",
    },
    {
      id: "premium",
      name: "Premium",
      price: "$9.99",
      period: "month",
      description: "Full access to all content including movies and videos",
      features: [
        "All Basic features",
        "Access to premium movies and videos",
        "Exclusive live streams",
        "Direct messaging with creator",
      ],
      icon: Crown,
      color: "text-brand-purple",
      bgColor: "bg-purple-100 dark:bg-purple-900/20",
      borderColor: "border-purple-200 dark:border-purple-800",
      popular: true,
    },
    {
      id: "ultimate",
      name: "Ultimate",
      price: "$19.99",
      period: "month",
      description: "VIP experience with personalized content and perks",
      features: [
        "All Premium features",
        "Priority access to new content",
        "Monthly personalized content",
        "Membership badge on comments",
        "Exclusive merchandise discounts",
      ],
      icon: Sparkles,
      color: "text-brand-pink",
      bgColor: "bg-pink-100 dark:bg-pink-900/20",
      borderColor: "border-pink-200 dark:border-pink-800",
    },
  ]

  const handleSubscribe = async (planId: string) => {
    setSelectedPlan(planId)
    setIsProcessing(true)

    try {
      // In a real app, this would process the payment and create the subscription
      await subscribeToPlan(planId)

      // Redirect to success page or show success message
      console.log(`Successfully subscribed to ${planId} plan`)
    } catch (error) {
      console.error("Failed to subscribe:", error)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">Become a Member</h2>
        <p className="mt-2 text-gray-600 dark:text-gray-400">
          Support your favorite creator and get access to exclusive content
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-xl ${
              plan.popular ? `border-2 ${plan.borderColor}` : ""
            }`}
          >
            {plan.popular && (
              <div className="absolute right-0 top-0 bg-gradient-to-r from-brand-purple to-brand-pink px-3 py-1 text-xs font-semibold text-white">
                POPULAR
              </div>
            )}
            <CardHeader className={`${plan.bgColor}`}>
              <div className="flex items-center gap-2">
                <div className={`rounded-full p-1.5 ${plan.color} bg-white/80 dark:bg-gray-800/80`}>
                  <plan.icon className="h-5 w-5" />
                </div>
                <CardTitle>{plan.name}</CardTitle>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="mb-4">
                <span className="text-3xl font-bold">{plan.price}</span>
                <span className="text-gray-500 dark:text-gray-400">/{plan.period}</span>
              </div>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Check className={`h-4 w-4 ${plan.color}`} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                className={`w-full ${
                  plan.id === "premium"
                    ? "bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                    : ""
                }`}
                onClick={() => handleSubscribe(plan.id)}
                disabled={isProcessing && selectedPlan === plan.id}
              >
                {isProcessing && selectedPlan === plan.id ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                  </>
                ) : (
                  "Subscribe"
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="mt-8 rounded-lg bg-gray-50 p-4 text-center text-sm text-gray-600 dark:bg-gray-800/50 dark:text-gray-400">
        <p>All plans include a 7-day free trial. Cancel anytime. No hidden fees.</p>
        <p className="mt-2">
          By subscribing, you agree to our{" "}
          <a
            href="#"
            className="text-brand-purple underline hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            Terms of Service
          </a>{" "}
          and{" "}
          <a
            href="#"
            className="text-brand-purple underline hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            Privacy Policy
          </a>
          .
        </p>
      </div>
    </div>
  )
}

