"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Play, Clock, Calendar, Film, DollarSign, Lock, Crown } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { PaymentModal } from "@/components/membership/payment-modal"

interface PremiumContentProps {
  content: any
}

export function PremiumContent({ content }: PremiumContentProps) {
  const router = useRouter()
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false)

  // Mock data for the premium content
  const mockContent = {
    id: "movie1",
    title: "Behind the Scenes: Tokyo Adventure",
    description:
      "Get exclusive access to behind-the-scenes footage from our Tokyo adventure. See how we filmed the most challenging scenes and hear stories that didn't make it to the final cut.",
    type: "Movie",
    duration: "1h 24m",
    releaseDate: "2023-03-15",
    creator: {
      name: "Travel Enthusiast",
      username: "travelenthusiast",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    thumbnail: "/placeholder.svg?height=720&width=1280",
    videoUrl: "#",
    views: 1245,
    likes: 342,
    comments: 86,
    membershipRequired: true,
    membershipTier: "premium",
    price: "$4.99",
    userHasAccess: false,
  }

  // Use the provided content or fallback to mock data
  const contentData = content || mockContent

  const handlePurchase = () => {
    setIsPaymentModalOpen(true)
  }

  const handlePaymentComplete = async (paymentDetails: any) => {
    try {
      // In a real app, you would process the payment
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Refresh the page to show the content
      router.refresh()
      setIsPaymentModalOpen(false)
    } catch (error) {
      console.error("Payment failed:", error)
    }
  }

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-lg bg-black">
        <div className="aspect-video w-full">
          <img
            src={contentData.thumbnail || "/placeholder.svg"}
            alt={contentData.title}
            className="h-full w-full object-cover opacity-70"
          />

          {!contentData.userHasAccess && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
              <Lock className="mb-4 h-16 w-16 text-white/80" />
              <h2 className="mb-2 text-2xl font-bold text-white">Premium Content</h2>
              {contentData.membershipRequired ? (
                <div className="text-center">
                  <p className="mb-4 text-white/80">This content requires a {contentData.membershipTier} membership</p>
                  <Button
                    onClick={() => router.push("/membership")}
                    className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                  >
                    <Crown className="mr-2 h-4 w-4" /> Subscribe Now
                  </Button>
                </div>
              ) : (
                <div className="text-center">
                  <p className="mb-4 text-white/80">Purchase this content for {contentData.price}</p>
                  <Button
                    onClick={handlePurchase}
                    className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                  >
                    <DollarSign className="mr-2 h-4 w-4" /> Purchase Now
                  </Button>
                </div>
              )}
            </div>
          )}

          {contentData.userHasAccess && (
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                size="lg"
                className="rounded-full bg-white/20 p-8 backdrop-blur-sm hover:bg-white/30"
                onClick={() => console.log("Play video")}
              >
                <Play className="h-8 w-8 text-white" fill="white" />
                <span className="sr-only">Play video</span>
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardContent className="p-6">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <h1 className="text-2xl font-bold">{contentData.title}</h1>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Film className="h-3 w-3" />
                    {contentData.type}
                  </Badge>
                  <Badge variant="outline" className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {contentData.duration}
                  </Badge>
                </div>
              </div>

              <div className="mb-6 flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={contentData.creator.avatar} alt={contentData.creator.name} />
                  <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                    {contentData.creator.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{contentData.creator.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">@{contentData.creator.username}</p>
                </div>
                <Button variant="outline" size="sm" className="ml-auto rounded-full">
                  Follow
                </Button>
              </div>

              <div className="mb-4 flex flex-wrap gap-4 text-sm text-gray-500 dark:text-gray-400">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>Released on {format(new Date(contentData.releaseDate), "MMMM d, yyyy")}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Film className="h-4 w-4" />
                  <span>{contentData.views.toLocaleString()} views</span>
                </div>
              </div>

              <p className="text-gray-700 dark:text-gray-300">{contentData.description}</p>

              {contentData.userHasAccess && (
                <div className="mt-6">
                  <Button
                    size="lg"
                    className="w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                    onClick={() => console.log("Play video")}
                  >
                    <Play className="mr-2 h-4 w-4" fill="white" /> Watch Now
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-1">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-lg font-semibold">Content Details</h2>

              <div className="space-y-4">
                {contentData.membershipRequired ? (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Access</h3>
                    <p className="flex items-center gap-2 font-medium">
                      <Crown className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                      Requires {contentData.membershipTier} membership
                    </p>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Price</h3>
                    <p className="flex items-center gap-2 font-medium">
                      <DollarSign className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                      {contentData.price} one-time purchase
                    </p>
                  </div>
                )}

                <div>
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Duration</h3>
                  <p className="flex items-center gap-2 font-medium">
                    <Clock className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                    {contentData.duration}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Release Date</h3>
                  <p className="flex items-center gap-2 font-medium">
                    <Calendar className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                    {format(new Date(contentData.releaseDate), "MMMM d, yyyy")}
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Category</h3>
                  <p className="flex items-center gap-2 font-medium">
                    <Film className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                    {contentData.type}
                  </p>
                </div>
              </div>

              {!contentData.userHasAccess && (
                <div className="mt-6">
                  {contentData.membershipRequired ? (
                    <Button
                      className="w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                      onClick={() => router.push("/membership")}
                    >
                      <Crown className="mr-2 h-4 w-4" /> Subscribe Now
                    </Button>
                  ) : (
                    <Button
                      className="w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                      onClick={handlePurchase}
                    >
                      <DollarSign className="mr-2 h-4 w-4" /> Purchase Now
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <PaymentModal
        open={isPaymentModalOpen}
        onOpenChange={setIsPaymentModalOpen}
        plan={{ name: contentData.title, price: contentData.price }}
        billingCycle="once"
        onPaymentComplete={handlePaymentComplete}
      />
    </div>
  )
}

