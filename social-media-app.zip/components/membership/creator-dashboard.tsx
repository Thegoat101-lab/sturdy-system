"use client"

import { useState } from "react"
import { BarChart, DollarSign, Film, Users, TrendingUp, Calendar } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PremiumContentUploadForm } from "@/components/membership/premium-content-upload-form"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function CreatorDashboard() {
  const [isUploadFormOpen, setIsUploadFormOpen] = useState(false)
  const [timeRange, setTimeRange] = useState("7d")

  // Mock data for the dashboard
  const stats = {
    subscribers: 1248,
    revenue: "$3,456.78",
    views: "24.5K",
    engagement: "18.2%",
  }

  const recentSubscribers = [
    {
      id: "1",
      name: "Alex Johnson",
      username: "alexj",
      avatar: "/placeholder.svg?height=40&width=40",
      plan: "Premium",
      date: "2 days ago",
    },
    {
      id: "2",
      name: "Sarah Williams",
      username: "sarahw",
      avatar: "/placeholder.svg?height=40&width=40",
      plan: "VIP",
      date: "3 days ago",
    },
    {
      id: "3",
      name: "Michael Brown",
      username: "michaelb",
      avatar: "/placeholder.svg?height=40&width=40",
      plan: "Basic",
      date: "5 days ago",
    },
  ]

  const premiumContent = [
    {
      id: "movie1",
      title: "Behind the Scenes: Tokyo Adventure",
      type: "Movie",
      thumbnail: "/placeholder.svg?height=720&width=1280",
      views: 1245,
      revenue: "$623.50",
      date: "2023-03-15",
    },
    {
      id: "movie2",
      title: "Exclusive Interview with Famous Director",
      type: "Interview",
      thumbnail: "/placeholder.svg?height=720&width=1280",
      views: 876,
      revenue: "$438.00",
      date: "2023-02-28",
    },
    {
      id: "movie3",
      title: "My Documentary: Life in the Wild",
      type: "Documentary",
      thumbnail: "/placeholder.svg?height=720&width=1280",
      views: 2340,
      revenue: "$1,170.00",
      date: "2023-01-20",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold">Welcome to your Creator Dashboard</h2>
          <p className="text-gray-500 dark:text-gray-400">Manage your premium content and track your earnings</p>
        </div>
        <Button
          onClick={() => setIsUploadFormOpen(true)}
          className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
        >
          <Film className="mr-2 h-4 w-4" /> Upload Premium Content
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Subscribers</CardTitle>
            <Users className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.subscribers}</div>
            <p className="text-xs text-green-500">+12% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.revenue}</div>
            <p className="text-xs text-green-500">+8% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Film className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.views}</div>
            <p className="text-xs text-green-500">+15% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.engagement}</div>
            <p className="text-xs text-green-500">+3% from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Recent Subscribers</CardTitle>
            <CardDescription>New members who subscribed to your premium content</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSubscribers.map((subscriber) => (
                <div key={subscriber.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={subscriber.avatar} alt={subscriber.name} />
                      <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                        {subscriber.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{subscriber.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">@{subscriber.username}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge
                      className={`${
                        subscriber.plan === "VIP"
                          ? "bg-gradient-to-r from-amber-500 to-yellow-500"
                          : subscriber.plan === "Premium"
                            ? "bg-gradient-to-r from-brand-purple to-brand-pink"
                            : "bg-gradient-to-r from-blue-400 to-blue-600"
                      } text-white`}
                    >
                      {subscriber.plan}
                    </Badge>
                    <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">{subscriber.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-1">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Revenue Analytics</CardTitle>
              <Tabs defaultValue="7d" value={timeRange} onValueChange={setTimeRange} className="w-[200px]">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="7d">7d</TabsTrigger>
                  <TabsTrigger value="30d">30d</TabsTrigger>
                  <TabsTrigger value="90d">90d</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <CardDescription>Your earnings over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] w-full">
              {/* This would be a chart in a real app */}
              <div className="flex h-full w-full items-center justify-center rounded-md border border-dashed border-gray-300 bg-gray-50 dark:border-gray-700 dark:bg-gray-800/50">
                <BarChart className="h-8 w-8 text-gray-400" />
                <span className="ml-2 text-gray-500">Revenue chart would appear here</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Premium Content</CardTitle>
          <CardDescription>Manage and track performance of your premium videos and movies</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {premiumContent.map((content) => (
              <div key={content.id} className="flex flex-col gap-4 rounded-lg border p-4 sm:flex-row">
                <div className="aspect-video w-full sm:w-48 overflow-hidden rounded-md">
                  <img
                    src={content.thumbnail || "/placeholder.svg"}
                    alt={content.title}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex flex-1 flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">{content.title}</h3>
                      <Badge variant="outline" className="text-xs">
                        {content.type}
                      </Badge>
                    </div>
                    <div className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(content.date), "MMM d, yyyy")}
                      </span>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Film className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">{content.views.toLocaleString()} views</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4 text-gray-500" />
                      <span className="text-sm">{content.revenue} earned</span>
                    </div>
                    <div className="ml-auto flex gap-2">
                      <Button size="sm" variant="outline">
                        Edit
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-500 hover:text-red-700">
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <PremiumContentUploadForm open={isUploadFormOpen} onOpenChange={setIsUploadFormOpen} />
    </div>
  )
}

