"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, Loader2, Film, DollarSign } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { uploadPremiumContent } from "@/lib/membership-actions"

interface PremiumContentUploadFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function PremiumContentUploadForm({ open, onOpenChange }: PremiumContentUploadFormProps) {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [contentType, setContentType] = useState("")
  const [price, setPrice] = useState("")
  const [membershipRequired, setMembershipRequired] = useState(true)
  const [membershipTier, setMembershipTier] = useState("basic")
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null)
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null)
  const [thumbnailPreviewUrl, setThumbnailPreviewUrl] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState("")
  const videoInputRef = useRef<HTMLInputElement>(null)
  const thumbnailInputRef = useRef<HTMLInputElement>(null)

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("video/")) {
      setError("Please select a video file")
      return
    }

    setVideoFile(file)
    setError("")

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setVideoPreviewUrl(url)
  }

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      setError("Please select an image file for the thumbnail")
      return
    }

    setThumbnailFile(file)
    setError("")

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setThumbnailPreviewUrl(url)
  }

  const clearVideoFile = () => {
    setVideoFile(null)
    setVideoPreviewUrl(null)
    if (videoInputRef.current) {
      videoInputRef.current.value = ""
    }
  }

  const clearThumbnailFile = () => {
    setThumbnailFile(null)
    setThumbnailPreviewUrl(null)
    if (thumbnailInputRef.current) {
      thumbnailInputRef.current.value = ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title.trim()) {
      setError("Please enter a title")
      return
    }

    if (!videoFile) {
      setError("Please select a video to upload")
      return
    }

    if (!contentType) {
      setError("Please select a content type")
      return
    }

    if (!membershipRequired && !price) {
      setError("Please enter a price for non-membership content")
      return
    }

    setIsUploading(true)
    setError("")

    try {
      // In a real app, this would upload the video and thumbnail to a storage service
      await uploadPremiumContent({
        title,
        description,
        contentType,
        price: membershipRequired ? "0" : price,
        membershipRequired,
        membershipTier: membershipRequired ? membershipTier : null,
        videoFile,
        thumbnailFile,
      })

      onOpenChange(false)
      router.refresh()

      // Reset form
      setTitle("")
      setDescription("")
      setContentType("")
      setPrice("")
      setMembershipRequired(true)
      setMembershipTier("basic")
      setVideoFile(null)
      setThumbnailFile(null)
      setVideoPreviewUrl(null)
      setThumbnailPreviewUrl(null)
    } catch (err) {
      setError("Failed to upload content. Please try again.")
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl bg-white/90 backdrop-blur-md dark:bg-gray-900/90">
        <DialogHeader>
          <DialogTitle className="bg-gradient-brand bg-clip-text text-transparent">Upload Premium Content</DialogTitle>
          <DialogDescription>
            Share exclusive content with your subscribers or set a price for individual purchases
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          {error && (
            <div className="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700 dark:bg-red-900/50 dark:text-red-200">
              {error}
            </div>
          )}

          <div className="grid gap-4 py-4 md:grid-cols-2">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter a title for your content"
                className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your content"
                rows={3}
                className="resize-none border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="contentType">Content Type</Label>
              <Select value={contentType} onValueChange={setContentType}>
                <SelectTrigger className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80">
                  <SelectValue placeholder="Select content type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Content Types</SelectLabel>
                    <SelectItem value="movie">Movie</SelectItem>
                    <SelectItem value="tutorial">Tutorial</SelectItem>
                    <SelectItem value="documentary">Documentary</SelectItem>
                    <SelectItem value="interview">Interview</SelectItem>
                    <SelectItem value="behindTheScenes">Behind the Scenes</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="membershipRequired">Require Membership</Label>
                <Switch id="membershipRequired" checked={membershipRequired} onCheckedChange={setMembershipRequired} />
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {membershipRequired
                  ? "Only members can access this content"
                  : "Anyone can purchase this content individually"}
              </p>
            </div>

            {membershipRequired ? (
              <div className="space-y-2">
                <Label htmlFor="membershipTier">Required Membership Tier</Label>
                <Select value={membershipTier} onValueChange={setMembershipTier}>
                  <SelectTrigger className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80">
                    <SelectValue placeholder="Select required tier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Membership Tiers</SelectLabel>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="premium">Premium</SelectItem>
                      <SelectItem value="vip">VIP</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="price">Price</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    id="price"
                    type="text"
                    value={price}
                    onChange={(e) => {
                      // Allow only numbers and decimal point
                      const value = e.target.value.replace(/[^0-9.]/g, "")
                      setPrice(value)
                    }}
                    placeholder="9.99"
                    className="pl-10 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="video">Upload Video</Label>
              <div className="flex flex-col gap-4 sm:flex-row">
                <div className="flex-1">
                  <div
                    className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-purple-200 p-6 transition-colors hover:border-brand-purple dark:border-purple-900 dark:hover:border-brand-pink"
                    onClick={() => videoInputRef.current?.click()}
                  >
                    <Film className="mb-2 h-8 w-8 text-gray-400" />
                    <p className="text-sm font-medium">Click to upload video</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">MP4, MOV, or WebM up to 500MB</p>
                    <input
                      ref={videoInputRef}
                      type="file"
                      id="video"
                      accept="video/*"
                      className="hidden"
                      onChange={handleVideoChange}
                    />
                  </div>
                </div>
                <div className="flex-1">
                  {videoPreviewUrl ? (
                    <div className="relative h-full rounded-lg border border-gray-200 dark:border-gray-800">
                      <div className="aspect-video w-full overflow-hidden rounded-lg">
                        <img
                          src="/placeholder.svg?height=720&width=1280"
                          alt="Video preview"
                          className="h-full w-full object-cover"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                          <svg className="h-16 w-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center justify-between p-2">
                        <span className="truncate text-sm">{videoFile?.name}</span>
                        <Button type="button" variant="ghost" size="sm" onClick={clearVideoFile}>
                          <X className="h-4 w-4" />
                          <span className="sr-only">Remove file</span>
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex h-full items-center justify-center rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900">
                      <p className="text-center text-sm text-gray-500">Video preview will appear here</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="thumbnail">Upload Thumbnail</Label>
              <div className="flex flex-col gap-4 sm:flex-row">
                <div className="flex-1">
                  <div
                    className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-purple-200 p-6 transition-colors hover:border-brand-purple dark:border-purple-900 dark:hover:border-brand-pink"
                    onClick={() => thumbnailInputRef.current?.click()}
                  >
                    <Upload className="mb-2 h-8 w-8 text-gray-400" />
                    <p className="text-sm font-medium">Click to upload thumbnail</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG or GIF up to 2MB</p>
                    <input
                      ref={thumbnailInputRef}
                      type="file"
                      id="thumbnail"
                      accept="image/*"
                      className="hidden"
                      onChange={handleThumbnailChange}
                    />
                  </div>
                </div>
                <div className="flex-1">
                  {thumbnailPreviewUrl ? (
                    <div className="relative h-full rounded-lg border border-gray-200 dark:border-gray-800">
                      <img
                        src={thumbnailPreviewUrl || "/placeholder.svg"}
                        alt="Thumbnail preview"
                        className="h-full w-full rounded-lg object-cover"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1 h-7 w-7 bg-black/50 text-white hover:bg-black/70"
                        onClick={clearThumbnailFile}
                      >
                        <X className="h-4 w-4" />
                        <span className="sr-only">Remove thumbnail</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="flex h-full items-center justify-center rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900">
                      <p className="text-center text-sm text-gray-500">Thumbnail preview will appear here</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isUploading}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isUploading}
              className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
            >
              {isUploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading...
                </>
              ) : (
                "Upload Content"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

