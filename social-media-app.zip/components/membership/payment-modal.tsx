"use client"

import type React from "react"

import { useState } from "react"
import { Loader2, CreditCard, Calendar, Lock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface PaymentModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  plan: any
  billingCycle: "monthly" | "yearly"
  onPaymentComplete: (paymentDetails: any) => void
}

export function PaymentModal({ open, onOpenChange, plan, billingCycle, onPaymentComplete }: PaymentModalProps) {
  const [cardNumber, setCardNumber] = useState("")
  const [cardName, setCardName] = useState("")
  const [expiryDate, setExpiryDate] = useState("")
  const [cvv, setCvv] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)
    setError("")

    // Basic validation
    if (!cardNumber || !cardName || !expiryDate || !cvv) {
      setError("All fields are required")
      setIsProcessing(false)
      return
    }

    try {
      // In a real app, you would process the payment through a payment gateway
      // This is just a simulation
      await new Promise((resolve) => setTimeout(resolve, 2000))

      onPaymentComplete({
        cardNumber,
        cardName,
        expiryDate,
        cvv,
      })

      // Reset form
      setCardNumber("")
      setCardName("")
      setExpiryDate("")
      setCvv("")
    } catch (err) {
      setError("Payment processing failed. Please try again.")
    } finally {
      setIsProcessing(false)
    }
  }

  if (!plan) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] bg-white/90 backdrop-blur-md dark:bg-gray-900/90">
        <DialogHeader>
          <DialogTitle className="bg-gradient-brand bg-clip-text text-transparent">
            Subscribe to {plan.name} Plan
          </DialogTitle>
          <DialogDescription>
            {billingCycle === "monthly"
              ? `You will be charged ${plan.price} per month.`
              : `You will be charged ${plan.price} per year.`}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          {error && (
            <div className="mb-4 rounded-md bg-red-50 p-3 text-sm text-red-700 dark:bg-red-900/50 dark:text-red-200">
              {error}
            </div>
          )}
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cardName">Cardholder Name</Label>
              <Input
                id="cardName"
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                placeholder="John Doe"
                className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="cardNumber">Card Number</Label>
              <div className="relative">
                <Input
                  id="cardNumber"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, "").slice(0, 16))}
                  placeholder="1234 5678 9012 3456"
                  className="pl-10 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                  maxLength={19}
                />
                <CreditCard className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="expiryDate">Expiry Date</Label>
                <div className="relative">
                  <Input
                    id="expiryDate"
                    value={expiryDate}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, "")
                      if (value.length <= 4) {
                        const month = value.slice(0, 2)
                        const year = value.slice(2, 4)
                        setExpiryDate(value.length > 2 ? `${month}/${year}` : month)
                      }
                    }}
                    placeholder="MM/YY"
                    className="pl-10 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                    maxLength={5}
                  />
                  <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="cvv">CVV</Label>
                <div className="relative">
                  <Input
                    id="cvv"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                    placeholder="123"
                    className="pl-10 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                    maxLength={3}
                    type="password"
                  />
                  <Lock className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="submit"
              disabled={isProcessing}
              className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                </>
              ) : (
                "Complete Payment"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

