"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { SendHorizonal, Gift, ThumbsUp, Smile } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"

interface StreamChatProps {
  channelName: string
}

export function StreamChat({ channelName }: StreamChatProps) {
  const [message, setMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Mock chat messages
  const chatMessages = [
    {
      id: "1",
      username: "gamerfan42",
      message: "Love the stream! Keep up the good work!",
      timestamp: "2 min ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: true,
    },
    {
      id: "2",
      username: "techie99",
      message: "What settings are you using?",
      timestamp: "1 min ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: false,
    },
    {
      id: "3",
      username: "streamlover",
      message: "This is amazing content! 🔥",
      timestamp: "45 sec ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: true,
    },
    {
      id: "4",
      username: "newviewer",
      message: "First time watching, instantly followed!",
      timestamp: "30 sec ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: false,
    },
    {
      id: "5",
      username: "supporter123",
      message: "Just subscribed! Can't wait for more streams",
      timestamp: "15 sec ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: true,
    },
    {
      id: "6",
      username: "chatmaster",
      message: "The quality of this stream is incredible",
      timestamp: "5 sec ago",
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscriber: true,
    },
  ]

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    // In a real app, you would send the message to a server
    console.log(`Sending message to ${channelName}: ${message}`)
    setMessage("")
  }

  // Auto-scroll to bottom when new messages come in
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [chatMessages])

  return (
    <Card className="flex h-[calc(100vh-15rem)] flex-col bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
      <CardHeader className="border-b px-4 py-3 dark:border-gray-800">
        <CardTitle className="text-lg">Live Chat</CardTitle>
      </CardHeader>
      <ScrollArea className="flex-1 px-4 py-2">
        <div className="space-y-4">
          {chatMessages.map((msg) => (
            <div key={msg.id} className="flex items-start gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={msg.avatar} alt={msg.username} />
                <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white text-xs">
                  {msg.username.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`font-semibold ${msg.isSubscriber ? "text-brand-purple dark:text-brand-pink" : ""}`}>
                    {msg.username}
                  </span>
                  {msg.isSubscriber && (
                    <span className="rounded bg-gradient-to-r from-brand-purple to-brand-pink px-1.5 py-0.5 text-xs text-white">
                      SUB
                    </span>
                  )}
                </div>
                <p className="text-sm">{msg.message}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{msg.timestamp}</p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      <div className="border-t p-4 dark:border-gray-800">
        <form onSubmit={sendMessage} className="flex gap-2">
          <Input
            placeholder="Send a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
          />
          <Button
            variant="ghost"
            size="icon"
            type="button"
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Gift className="h-5 w-5" />
            <span className="sr-only">Send gift</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            type="button"
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <ThumbsUp className="h-5 w-5" />
            <span className="sr-only">Like</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            type="button"
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Smile className="h-5 w-5" />
            <span className="sr-only">Add emoji</span>
          </Button>
          <Button
            type="submit"
            size="icon"
            disabled={!message.trim()}
            className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
          >
            <SendHorizonal className="h-5 w-5" />
            <span className="sr-only">Send message</span>
          </Button>
        </form>
      </div>
    </Card>
  )
}

