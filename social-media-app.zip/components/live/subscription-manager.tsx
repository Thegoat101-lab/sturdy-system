"use client"

import { useState } from "react"
import { Search, BellRing, BellOff, VideoOff, Video } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export function SubscriptionManager() {
  const [searchQuery, setSearchQuery] = useState("")

  // Mock subscriptions data
  const subscriptions = [
    {
      id: "1",
      channelName: "Gamer Girl",
      username: "gamergirl",
      avatar: "/placeholder.svg?height=40&width=40",
      isLive: true,
      category: "Gaming",
      viewers: 1245,
      notificationsOn: true,
      subscribedDate: "3 months ago",
    },
    {
      id: "2",
      channelName: "Tech Review",
      username: "techreview",
      avatar: "/placeholder.svg?height=40&width=40",
      isLive: true,
      category: "Technology",
      viewers: 2340,
      notificationsOn: true,
      subscribedDate: "1 month ago",
    },
    {
      id: "3",
      channelName: "Travel Buddy",
      username: "travelbuddy",
      avatar: "/placeholder.svg?height=40&width=40",
      isLive: false,
      category: "Travel",
      viewers: 0,
      notificationsOn: false,
      subscribedDate: "2 weeks ago",
    },
    {
      id: "4",
      channelName: "Fitness Trainer",
      username: "fitnesstrainer",
      avatar: "/placeholder.svg?height=40&width=40",
      isLive: false,
      category: "Fitness",
      viewers: 0,
      notificationsOn: true,
      subscribedDate: "1 week ago",
    },
    {
      id: "5",
      channelName: "Music Producer",
      username: "musicproducer",
      avatar: "/placeholder.svg?height=40&width=40",
      isLive: false,
      category: "Music",
      viewers: 0,
      notificationsOn: false,
      subscribedDate: "2 days ago",
    },
  ]

  const filteredSubscriptions = subscriptions.filter(
    (sub) =>
      sub.channelName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const liveSubscriptions = filteredSubscriptions.filter((sub) => sub.isLive)
  const offlineSubscriptions = filteredSubscriptions.filter((sub) => !sub.isLive)

  const toggleNotifications = (id: string, currentState: boolean) => {
    // In a real app, you would update this in the database
    console.log(`Toggling notifications for ${id} from ${currentState} to ${!currentState}`)
  }

  return (
    <div className="space-y-6">
      <div className="relative max-w-md">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
        <Input
          type="search"
          placeholder="Search subscriptions..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-8 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
        />
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            All
          </TabsTrigger>
          <TabsTrigger
            value="live"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Live Now {liveSubscriptions.length > 0 && `(${liveSubscriptions.length})`}
          </TabsTrigger>
          <TabsTrigger
            value="offline"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Offline
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <SubscriptionList subscriptions={filteredSubscriptions} toggleNotifications={toggleNotifications} />
        </TabsContent>

        <TabsContent value="live" className="mt-6">
          {liveSubscriptions.length === 0 ? (
            <Card className="bg-white/80 p-8 text-center backdrop-blur-sm dark:bg-gray-900/80">
              <CardContent className="pt-6">
                <VideoOff className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-4 text-lg font-medium">No live channels</h3>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  None of your subscribed channels are currently streaming.
                </p>
              </CardContent>
            </Card>
          ) : (
            <SubscriptionList subscriptions={liveSubscriptions} toggleNotifications={toggleNotifications} />
          )}
        </TabsContent>

        <TabsContent value="offline" className="mt-6">
          <SubscriptionList subscriptions={offlineSubscriptions} toggleNotifications={toggleNotifications} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface SubscriptionListProps {
  subscriptions: Array<{
    id: string
    channelName: string
    username: string
    avatar: string
    isLive: boolean
    category: string
    viewers: number
    notificationsOn: boolean
    subscribedDate: string
  }>
  toggleNotifications: (id: string, currentState: boolean) => void
}

function SubscriptionList({ subscriptions, toggleNotifications }: SubscriptionListProps) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {subscriptions.map((sub) => (
        <Card
          key={sub.id}
          className="overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-xl bg-white/80 backdrop-blur-sm dark:bg-gray-900/80"
        >
          <Link href={`/live/${sub.username}`} className="block">
            <div className="relative h-32 w-full bg-gray-100 dark:bg-gray-800">
              {sub.isLive ? (
                <>
                  <img
                    src="/placeholder.svg?height=720&width=1280"
                    alt={`${sub.channelName} stream`}
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute bottom-2 left-2 flex items-center rounded-full bg-red-600 px-2 py-1 text-xs text-white">
                    <span className="mr-1 h-2 w-2 rounded-full bg-white"></span>
                    LIVE
                  </div>
                  <div className="absolute bottom-2 right-2 flex items-center rounded-full bg-black/70 px-2 py-1 text-xs text-white backdrop-blur-sm">
                    {sub.viewers.toLocaleString()} viewers
                  </div>
                </>
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center">
                  <Video className="h-8 w-8 text-gray-400" />
                  <p className="mt-2 text-sm text-gray-500">Offline</p>
                </div>
              )}
            </div>
          </Link>

          <CardContent className="p-4">
            <div className="flex items-start justify-between">
              <Link href={`/live/${sub.username}`} className="flex items-start gap-3">
                <Avatar className={`h-10 w-10 ${sub.isLive ? "ring-2 ring-brand-pink ring-offset-1" : ""}`}>
                  <AvatarImage src={sub.avatar} alt={sub.channelName} />
                  <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                    {sub.channelName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{sub.channelName}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">@{sub.username}</p>
                  <Badge className="mt-1 bg-gray-100 text-xs text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700">
                    {sub.category}
                  </Badge>
                </div>
              </Link>
              <div className="flex items-center">
                <div className="flex items-center space-x-2">
                  <Switch
                    id={`notifications-${sub.id}`}
                    checked={sub.notificationsOn}
                    onCheckedChange={(checked) => toggleNotifications(sub.id, sub.notificationsOn)}
                  />
                  <Label htmlFor={`notifications-${sub.id}`} className="sr-only">
                    Notifications
                  </Label>
                  {sub.notificationsOn ? (
                    <BellRing className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                  ) : (
                    <BellOff className="h-4 w-4 text-gray-400" />
                  )}
                </div>
              </div>
            </div>
            <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">Subscribed {sub.subscribedDate}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

