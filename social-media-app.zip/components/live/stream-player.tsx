"use client"

import { useState } from "react"
import { Heart, MessageSquare, Share2, Users } from "lucide-react"

import { Button } from "@/components/ui/button"

interface Channel {
  id: string
  username: string
  name: string
  avatar: string
  isLive: boolean
  title: string
  category: string
  viewers: number
  followers: number
  description: string
  tags: string[]
  subscriberCount: number
  isSubscribed: boolean
  isBellOn: boolean
}

interface StreamPlayerProps {
  channel: Channel
}

export function StreamPlayer({ channel }: StreamPlayerProps) {
  const [likes, setLikes] = useState(0)
  const [hasLiked, setHasLiked] = useState(false)

  const handleLike = () => {
    if (hasLiked) {
      setLikes(likes - 1)
    } else {
      setLikes(likes + 1)
    }
    setHasLiked(!hasLiked)
  }

  return (
    <div className="relative overflow-hidden rounded-lg bg-black">
      <div className="aspect-video w-full">
        {/* Video player would go here in a real app */}
        <img src="/placeholder.svg?height=720&width=1280" alt="Live stream" className="h-full w-full object-cover" />

        {/* Live indicator and viewer count */}
        <div className="absolute left-4 top-4 flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-full bg-red-600 px-2 py-1 text-sm font-bold text-white">
            LIVE
          </div>
          <div className="flex items-center gap-1 rounded-full bg-black/70 px-2 py-1 text-sm text-white backdrop-blur-sm">
            <Users className="h-4 w-4" />
            <span>{channel.viewers.toLocaleString()}</span>
          </div>
        </div>

        {/* Interaction buttons */}
        <div className="absolute bottom-4 right-4 flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-black/30 text-white backdrop-blur-sm hover:bg-brand-purple/60"
            onClick={handleLike}
          >
            <Heart className={`h-5 w-5 ${hasLiked ? "fill-brand-pink text-brand-pink" : ""}`} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-black/30 text-white backdrop-blur-sm hover:bg-brand-purple/60"
          >
            <MessageSquare className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-black/30 text-white backdrop-blur-sm hover:bg-brand-purple/60"
          >
            <Share2 className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}

