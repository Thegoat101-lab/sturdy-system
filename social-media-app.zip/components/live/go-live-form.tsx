"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, Loader2, Video, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { startStream } from "@/lib/stream-actions"

export function GoLiveForm() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [tag, setTag] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null)
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null)
  const [isStarting, setIsStarting] = useState(false)
  const [error, setError] = useState("")
  const thumbnailInputRef = useRef<HTMLInputElement>(null)

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (!file.type.startsWith("image/")) {
      setError("Please select an image file for the thumbnail")
      return
    }

    setThumbnailFile(file)
    setError("")

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setThumbnailUrl(url)
  }

  const handleAddTag = () => {
    if (!tag.trim()) return
    if (tags.includes(tag.toLowerCase())) return
    if (tags.length >= 5) {
      setError("You can only add up to 5 tags")
      return
    }

    setTags([...tags, tag.toLowerCase()])
    setTag("")
    setError("")
  }

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove))
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleAddTag()
    }
  }

  const clearThumbnail = () => {
    setThumbnailFile(null)
    setThumbnailUrl(null)
    if (thumbnailInputRef.current) {
      thumbnailInputRef.current.value = ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) {
      setError("Please enter a stream title")
      return
    }

    if (!category) {
      setError("Please select a category")
      return
    }

    setIsStarting(true)
    setError("")

    try {
      // In a real app, this would start the stream and upload the thumbnail
      await startStream({
        title,
        description,
        category,
        tags,
        thumbnail: thumbnailFile,
      })
      router.push("/live/username")
    } catch (err) {
      setError("Failed to start stream. Please try again.")
    } finally {
      setIsStarting(false)
    }
  }

  // Categories for streaming
  const categories = [
    { value: "gaming", label: "Gaming" },
    { value: "just-chatting", label: "Just Chatting" },
    { value: "music", label: "Music" },
    { value: "art", label: "Art" },
    { value: "travel", label: "Travel & Outdoors" },
    { value: "technology", label: "Technology" },
    { value: "sports", label: "Sports" },
    { value: "cooking", label: "Cooking & Food" },
    { value: "education", label: "Education" },
    { value: "fitness", label: "Fitness & Health" },
  ]

  return (
    <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
      <CardContent className="p-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <div className="rounded-md bg-red-50 p-4 text-sm text-red-700 dark:bg-red-900/50 dark:text-red-200">
              {error}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-1">
              <Label htmlFor="title">Stream Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter an engaging title for your stream"
                maxLength={100}
                className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
              />
              <p className="text-xs text-gray-500">{title.length}/100 characters</p>
            </div>

            <div className="space-y-2 sm:col-span-1">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectLabel>Categories</SelectLabel>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="description">Stream Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Tell viewers what your stream is about"
                rows={4}
                className="resize-none border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
              />
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="tags">Tags</Label>
              <div className="flex gap-2">
                <Input
                  id="tags"
                  value={tag}
                  onChange={(e) => setTag(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Add tags to help viewers find your stream"
                  className="flex-1 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                />
                <Button
                  type="button"
                  onClick={handleAddTag}
                  className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                >
                  Add
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 pt-2">
                {tags.map((t) => (
                  <Badge
                    key={t}
                    variant="secondary"
                    className="flex gap-1 items-center bg-brand-purple/10 text-brand-purple dark:bg-brand-pink/10 dark:text-brand-pink"
                  >
                    #{t}
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-4 w-4 p-0 hover:bg-transparent"
                      onClick={() => handleRemoveTag(t)}
                    >
                      <X className="h-3 w-3" />
                      <span className="sr-only">Remove tag</span>
                    </Button>
                  </Badge>
                ))}
                {tags.length === 0 && (
                  <p className="text-xs text-gray-500 dark:text-gray-400">Add up to 5 tags to categorize your stream</p>
                )}
              </div>
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="thumbnail">Stream Thumbnail</Label>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <div
                    className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-purple-200 p-4 transition-colors hover:border-brand-purple dark:border-purple-900 dark:hover:border-brand-pink"
                    onClick={() => thumbnailInputRef.current?.click()}
                  >
                    <Upload className="mb-2 h-8 w-8 text-gray-400" />
                    <p className="text-sm font-medium">Click to upload thumbnail</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG or GIF up to 2MB</p>
                    <input
                      ref={thumbnailInputRef}
                      type="file"
                      id="thumbnail"
                      accept="image/*"
                      className="hidden"
                      onChange={handleThumbnailChange}
                    />
                  </div>
                </div>
                <div>
                  {thumbnailUrl ? (
                    <div className="relative h-full rounded-lg border border-gray-200 dark:border-gray-800">
                      <img
                        src={thumbnailUrl || "/placeholder.svg"}
                        alt="Thumbnail preview"
                        className="h-full w-full rounded-lg object-cover"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1 h-7 w-7 bg-black/50 text-white hover:bg-black/70"
                        onClick={clearThumbnail}
                      >
                        <X className="h-4 w-4" />
                        <span className="sr-only">Remove thumbnail</span>
                      </Button>
                    </div>
                  ) : (
                    <div className="flex h-full items-center justify-center rounded-lg border border-gray-200 bg-gray-50 p-4 dark:border-gray-800 dark:bg-gray-900">
                      <p className="text-center text-sm text-gray-500">Thumbnail preview will appear here</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-2 sm:col-span-2">
              <div className="flex flex-col gap-4 rounded-lg bg-gray-50 p-4 dark:bg-gray-800/50">
                <div className="flex items-center gap-3">
                  <Video className="h-5 w-5 text-brand-purple dark:text-brand-pink" />
                  <div>
                    <h3 className="text-sm font-medium">Stream Setup</h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      To configure your stream, use the following information in your broadcasting software
                    </p>
                  </div>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label className="text-xs">Server URL</Label>
                    <div className="flex">
                      <Input
                        readOnly
                        value="rtmp://stream.example.com/live"
                        className="rounded-r-none border-r-0 bg-white dark:bg-gray-950"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        className="rounded-l-none border-l-0"
                        onClick={() => navigator.clipboard.writeText("rtmp://stream.example.com/live")}
                      >
                        Copy
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Stream Key</Label>
                    <div className="flex">
                      <Input
                        readOnly
                        type="password"
                        value="sk_live_123456789"
                        className="rounded-r-none border-r-0 bg-white dark:bg-gray-950"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        className="rounded-l-none border-l-0"
                        onClick={() => navigator.clipboard.writeText("sk_live_123456789")}
                      >
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Settings className="h-4 w-4 text-gray-500" />
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    Need help? Check out our{" "}
                    <a href="#" className="text-brand-purple hover:underline dark:text-brand-pink">
                      stream setup guide
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.back()}
              className="border-gray-300 hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isStarting}
              className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
            >
              {isStarting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Starting Stream...
                </>
              ) : (
                "Go Live"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

