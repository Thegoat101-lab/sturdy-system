"use client"

import { useState } from "react"
import { BellOff, BellRing, ThumbsUp, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

interface Channel {
  id: string
  username: string
  name: string
  avatar: string
  isLive: boolean
  title: string
  category: string
  viewers: number
  followers: number
  description: string
  tags: string[]
  subscriberCount: number
  isSubscribed: boolean
  isBellOn: boolean
}

interface ChannelInfoProps {
  channel: Channel
}

export function ChannelInfo({ channel }: ChannelInfoProps) {
  const [isSubscribed, setIsSubscribed] = useState(channel.isSubscribed)
  const [isBellOn, setIsBellOn] = useState(channel.isBellOn)
  const [subscriberCount, setSubscriberCount] = useState(channel.subscriberCount)

  const toggleSubscribe = () => {
    if (isSubscribed) {
      setSubscriberCount(subscriberCount - 1)
    } else {
      setSubscriberCount(subscriberCount + 1)
      if (!isBellOn) setIsBellOn(true)
    }
    setIsSubscribed(!isSubscribed)
  }

  const toggleBell = () => {
    setIsBellOn(!isBellOn)
  }

  return (
    <div className="mt-4 space-y-4">
      <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <CardContent className="p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <Avatar className="h-12 w-12 sm:h-16 sm:w-16 border-2 border-brand-pink">
                <AvatarImage src={channel.avatar} alt={channel.name} />
                <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                  {channel.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-xl font-bold sm:text-2xl">{channel.title}</h1>
                <div className="mt-1 flex items-center gap-2">
                  <p className="font-medium">{channel.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">• @{channel.username}</p>
                </div>
                <div className="mt-1 flex items-center gap-3 text-sm">
                  <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                    <Users className="h-4 w-4" />
                    <span>{channel.followers.toLocaleString()} followers</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{subscriberCount.toLocaleString()} subscribers</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleBell}
                disabled={!isSubscribed}
                className={`h-10 w-10 ${
                  isBellOn
                    ? "text-brand-pink hover:text-brand-purple dark:text-brand-pink dark:hover:text-brand-purple"
                    : "text-gray-400"
                }`}
              >
                {isBellOn ? <BellRing className="h-5 w-5" /> : <BellOff className="h-5 w-5" />}
                <span className="sr-only">{isBellOn ? "Notifications on" : "Notifications off"}</span>
              </Button>

              <Button
                onClick={toggleSubscribe}
                className={`${
                  isSubscribed
                    ? "border-2 border-brand-purple bg-white text-brand-purple hover:border-brand-pink hover:bg-white hover:text-brand-pink dark:border-brand-pink dark:bg-gray-900 dark:text-brand-pink"
                    : "bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                }`}
              >
                {isSubscribed ? "Subscribed" : "Subscribe"}
              </Button>
            </div>
          </div>

          <div className="mt-4">
            <div className="flex flex-wrap gap-2">
              <Badge className="bg-brand-purple text-white hover:bg-brand-purple/90 dark:bg-brand-pink dark:hover:bg-brand-pink/90">
                {channel.category}
              </Badge>
              {channel.tags.map((tag) => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="border-brand-purple text-brand-purple dark:border-brand-pink dark:text-brand-pink"
                >
                  #{tag}
                </Badge>
              ))}
            </div>
            <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">{channel.description}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

