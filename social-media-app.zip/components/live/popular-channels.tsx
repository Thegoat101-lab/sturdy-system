import Link from "next/link"
import { BellOff, BellRing } from "lucide-react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function PopularChannels() {
  const popularChannels = [
    {
      id: "1",
      username: "gamergirl",
      name: "Gamer Girl",
      category: "Gaming",
      isLive: true,
      viewers: 1245,
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscribed: false,
    },
    {
      id: "2",
      username: "travelbuddy",
      name: "Travel Buddy",
      category: "Travel",
      isLive: true,
      viewers: 875,
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscribed: true,
    },
    {
      id: "3",
      username: "techreview",
      name: "Tech Review",
      category: "Technology",
      isLive: true,
      viewers: 2340,
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscribed: false,
    },
    {
      id: "4",
      username: "musicproducer",
      name: "Music Producer",
      category: "Music",
      isLive: false,
      viewers: 0,
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscribed: true,
    },
    {
      id: "5",
      username: "fitnesstrainer",
      name: "Fitness Trainer",
      category: "Fitness",
      isLive: false,
      viewers: 0,
      avatar: "/placeholder.svg?height=40&width=40",
      isSubscribed: false,
    },
  ]

  return (
    <div className="space-y-4">
      <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Popular Channels</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          {popularChannels.map((channel) => (
            <div key={channel.id} className="flex items-center justify-between">
              <Link href={`/live/${channel.username}`} className="flex items-center gap-3 hover:opacity-80">
                <div className="relative">
                  <Avatar className="h-10 w-10 border-2 border-brand-pink">
                    <AvatarImage src={channel.avatar} alt={channel.name} />
                    <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                      {channel.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {channel.isLive && (
                    <span className="absolute -bottom-1 -right-1 h-3 w-3 rounded-full bg-red-500 ring-2 ring-white dark:ring-gray-900"></span>
                  )}
                </div>
                <div>
                  <div className="font-medium">{channel.name}</div>
                  <div className="flex items-center text-xs">
                    <span className="text-gray-500 dark:text-gray-400">{channel.category}</span>
                    {channel.isLive && (
                      <>
                        <span className="mx-1">•</span>
                        <span className="text-red-500">{channel.viewers} viewers</span>
                      </>
                    )}
                  </div>
                </div>
              </Link>
              <div className="flex items-center gap-1">
                {channel.isSubscribed ? (
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-brand-pink">
                    <BellRing className="h-4 w-4" />
                    <span className="sr-only">Notifications on</span>
                  </Button>
                ) : (
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-400">
                    <BellOff className="h-4 w-4" />
                    <span className="sr-only">Notifications off</span>
                  </Button>
                )}
                <Button
                  size="sm"
                  variant={channel.isSubscribed ? "outline" : "default"}
                  className={`h-7 text-xs ${
                    channel.isSubscribed
                      ? "border-brand-purple text-brand-purple hover:border-brand-pink hover:text-brand-pink dark:border-brand-pink dark:text-brand-pink"
                      : "bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                  }`}
                >
                  {channel.isSubscribed ? "Subscribed" : "Subscribe"}
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

