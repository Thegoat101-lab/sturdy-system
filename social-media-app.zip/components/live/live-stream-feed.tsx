"use client"

import { useState } from "react"
import Link from "next/link"
import { Eye, Users } from "lucide-react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

export function LiveStreamFeed() {
  const [streamCategory, setStreamCategory] = useState("all")

  // Mock live stream data for different categories
  const liveStreams = {
    all: [
      {
        id: "1",
        username: "gamergirl",
        title: "Playing the new FPS game with viewers!",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Gaming",
        tags: ["fps", "multiplayer"],
        viewers: 1245,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "2",
        username: "travelbuddy",
        title: "Live from Tokyo - Cherry blossom season!",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Travel",
        tags: ["japan", "travel"],
        viewers: 875,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "3",
        username: "techreview",
        title: "Unboxing the latest smartphones - Live Q&A",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Technology",
        tags: ["tech", "smartphones"],
        viewers: 2340,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "4",
        username: "musicproducer",
        title: "Creating a beat from scratch - Watch the process",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Music",
        tags: ["production", "electronic"],
        viewers: 945,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "5",
        username: "fitnesstrainer",
        title: "Live workout session - Cardio & Strength",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Fitness",
        tags: ["workout", "fitness"],
        viewers: 1120,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "6",
        username: "artcreator",
        title: "Digital art creation - Fantasy character design",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Art",
        tags: ["digital", "fantasy"],
        viewers: 760,
        avatar: "/placeholder.svg?height=40&width=40",
      },
    ],
    following: [
      {
        id: "3",
        username: "techreview",
        title: "Unboxing the latest smartphones - Live Q&A",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Technology",
        tags: ["tech", "smartphones"],
        viewers: 2340,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "5",
        username: "fitnesstrainer",
        title: "Live workout session - Cardio & Strength",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Fitness",
        tags: ["workout", "fitness"],
        viewers: 1120,
        avatar: "/placeholder.svg?height=40&width=40",
      },
    ],
    recommended: [
      {
        id: "1",
        username: "gamergirl",
        title: "Playing the new FPS game with viewers!",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Gaming",
        tags: ["fps", "multiplayer"],
        viewers: 1245,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "4",
        username: "musicproducer",
        title: "Creating a beat from scratch - Watch the process",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Music",
        tags: ["production", "electronic"],
        viewers: 945,
        avatar: "/placeholder.svg?height=40&width=40",
      },
      {
        id: "6",
        username: "artcreator",
        title: "Digital art creation - Fantasy character design",
        thumbnail: "/placeholder.svg?height=720&width=1280",
        category: "Art",
        tags: ["digital", "fantasy"],
        viewers: 760,
        avatar: "/placeholder.svg?height=40&width=40",
      },
    ],
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h1 className="bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">Live Streams</h1>
        <Button
          asChild
          className="mt-2 bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple sm:mt-0"
        >
          <Link href="/go-live">Start Streaming</Link>
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            All Streams
          </TabsTrigger>
          <TabsTrigger
            value="following"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Following
          </TabsTrigger>
          <TabsTrigger
            value="recommended"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Recommended
          </TabsTrigger>
        </TabsList>

        {Object.entries(liveStreams).map(([category, streams]) => (
          <TabsContent key={category} value={category} className="mt-6">
            {streams.length === 0 ? (
              <Card className="bg-white/80 p-8 text-center shadow-lg backdrop-blur-sm dark:bg-gray-900/80">
                <CardContent className="pt-6">
                  <Users className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium">No live streams available</h3>
                  <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                    {category === "following"
                      ? "Follow some channels to see them here when they go live."
                      : "Check back later for more streams!"}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {streams.map((stream) => (
                  <Link key={stream.id} href={`/live/${stream.username}`}>
                    <Card className="overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-xl">
                      <div className="relative">
                        <img
                          src={stream.thumbnail || "/placeholder.svg"}
                          alt={stream.title}
                          className="aspect-video w-full object-cover"
                        />
                        <div className="absolute bottom-2 left-2 flex items-center rounded-full bg-black/70 px-2 py-1 text-xs text-white backdrop-blur-sm">
                          <Eye className="mr-1 h-3.5 w-3.5" />
                          <span>{stream.viewers.toLocaleString()} viewers</span>
                        </div>
                        <div className="absolute right-2 top-2 rounded-md bg-red-600 px-2 py-1 text-xs font-semibold text-white">
                          LIVE
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="h-10 w-10 border-2 border-brand-pink">
                            <AvatarImage src={stream.avatar} alt={stream.username} />
                            <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                              {stream.username.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 overflow-hidden">
                            <h3 className="truncate font-semibold">{stream.title}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">@{stream.username}</p>
                            <p className="mt-1 text-xs font-medium text-brand-purple dark:text-brand-pink">
                              {stream.category}
                            </p>
                            <div className="mt-2 flex flex-wrap gap-1">
                              {stream.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  #{tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

