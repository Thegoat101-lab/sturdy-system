"use client"

import { useState } from "react"
import { Search, UserPlus, Check, X, Phone, Video, Mail } from "lucide-react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { acceptFriendRequest, rejectFriendRequest, sendFriendRequest, removeFriend } from "@/lib/friend-actions"
import { toast } from "@/hooks/use-toast"

export function FriendsManager() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({})

  // Mock data - in a real app, this would come from your API
  const friendRequests = [
    {
      id: "req1",
      user: {
        id: "user1",
        name: "Alex Johnson",
        username: "alexj",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      date: "2 days ago",
    },
    {
      id: "req2",
      user: {
        id: "user2",
        name: "Maria Garcia",
        username: "mariag",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      date: "5 days ago",
    },
  ]

  const friends = [
    {
      id: "friend1",
      name: "Jane Smith",
      username: "janes",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "online",
      lastActive: "Now",
    },
    {
      id: "friend2",
      name: "David Kim",
      username: "davidk",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "offline",
      lastActive: "3 hours ago",
    },
    {
      id: "friend3",
      name: "Sarah Williams",
      username: "sarahw",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "online",
      lastActive: "Now",
    },
  ]

  const suggestedFriends = [
    {
      id: "sug1",
      name: "Michael Brown",
      username: "michaelb",
      avatar: "/placeholder.svg?height=40&width=40",
      mutualFriends: 5,
    },
    {
      id: "sug2",
      name: "Emily Davis",
      username: "emilyd",
      avatar: "/placeholder.svg?height=40&width=40",
      mutualFriends: 3,
    },
    {
      id: "sug3",
      name: "Robert Wilson",
      username: "robertw",
      avatar: "/placeholder.svg?height=40&width=40",
      mutualFriends: 2,
    },
  ]

  const handleAcceptRequest = async (requestId: string, userId: string) => {
    setIsLoading((prev) => ({ ...prev, [requestId]: true }))
    try {
      await acceptFriendRequest(requestId)
      toast({
        title: "Friend request accepted",
        description: "You are now friends!",
      })
      // In a real app, you would update the UI by refetching data
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to accept friend request",
        variant: "destructive",
      })
    } finally {
      setIsLoading((prev) => ({ ...prev, [requestId]: false }))
    }
  }

  const handleRejectRequest = async (requestId: string) => {
    setIsLoading((prev) => ({ ...prev, [requestId]: true }))
    try {
      await rejectFriendRequest(requestId)
      toast({
        title: "Friend request rejected",
      })
      // In a real app, you would update the UI by refetching data
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject friend request",
        variant: "destructive",
      })
    } finally {
      setIsLoading((prev) => ({ ...prev, [requestId]: false }))
    }
  }

  const handleSendRequest = async (userId: string) => {
    setIsLoading((prev) => ({ ...prev, [userId]: true }))
    try {
      await sendFriendRequest(userId)
      toast({
        title: "Friend request sent",
      })
      // In a real app, you would update the UI by refetching data
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send friend request",
        variant: "destructive",
      })
    } finally {
      setIsLoading((prev) => ({ ...prev, [userId]: false }))
    }
  }

  const handleRemoveFriend = async (friendId: string) => {
    setIsLoading((prev) => ({ ...prev, [friendId]: true }))
    try {
      await removeFriend(friendId)
      toast({
        title: "Friend removed",
      })
      // In a real app, you would update the UI by refetching data
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove friend",
        variant: "destructive",
      })
    } finally {
      setIsLoading((prev) => ({ ...prev, [friendId]: false }))
    }
  }

  const handleCall = (friendId: string, type: "audio" | "video") => {
    // In a real app, this would initiate a call
    toast({
      title: `Initiating ${type} call`,
      description: `Calling ${friends.find((f) => f.id === friendId)?.name}...`,
    })
    // Redirect to call page or open call modal
    window.location.href = `/call/${friendId}?type=${type}`
  }

  const handleMessage = (friendId: string) => {
    // In a real app, this would open the messaging interface
    window.location.href = `/messages?friend=${friendId}`
  }

  const filteredFriends = friends.filter(
    (friend) =>
      friend.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      friend.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500 dark:text-gray-400" />
        <Input
          type="search"
          placeholder="Search friends..."
          className="pl-10 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="all">
        <TabsList className="grid w-full grid-cols-4 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger
            value="all"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            All Friends
          </TabsTrigger>
          <TabsTrigger
            value="online"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Online
          </TabsTrigger>
          <TabsTrigger
            value="requests"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Requests
            {friendRequests.length > 0 && <Badge className="ml-2 bg-brand-pink">{friendRequests.length}</Badge>}
          </TabsTrigger>
          <TabsTrigger
            value="suggestions"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Suggestions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredFriends.length > 0 ? (
              filteredFriends.map((friend) => (
                <Card key={friend.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <Avatar>
                            <AvatarImage src={friend.avatar} alt={friend.name} />
                            <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                              {friend.name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <span
                            className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${
                              friend.status === "online" ? "bg-green-500" : "bg-gray-400"
                            }`}
                          />
                        </div>
                        <div>
                          <p className="font-medium">{friend.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">@{friend.username}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {friend.status === "online" ? "Online" : `Last active ${friend.lastActive}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                          onClick={() => handleCall(friend.id, "audio")}
                        >
                          <Phone className="h-4 w-4" />
                          <span className="sr-only">Call</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                          onClick={() => handleCall(friend.id, "video")}
                        >
                          <Video className="h-4 w-4" />
                          <span className="sr-only">Video Call</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                          onClick={() => handleMessage(friend.id)}
                        >
                          <Mail className="h-4 w-4" />
                          <span className="sr-only">Message</span>
                        </Button>
                      </div>
                    </div>
                    <div className="flex border-t dark:border-gray-800">
                      <Button
                        variant="ghost"
                        className="flex-1 rounded-none text-sm"
                        onClick={() => (window.location.href = `/profile/${friend.username}`)}
                      >
                        View Profile
                      </Button>
                      <Button
                        variant="ghost"
                        className="flex-1 rounded-none text-sm text-red-500 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/20"
                        onClick={() => handleRemoveFriend(friend.id)}
                        disabled={isLoading[friend.id]}
                      >
                        Remove Friend
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full flex h-40 items-center justify-center rounded-lg border bg-white/50 dark:border-gray-800 dark:bg-gray-900/50">
                <p className="text-gray-500 dark:text-gray-400">No friends found matching your search</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="online" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredFriends.filter((f) => f.status === "online").length > 0 ? (
              filteredFriends
                .filter((f) => f.status === "online")
                .map((friend) => (
                  <Card key={friend.id} className="overflow-hidden">
                    <CardContent className="p-0">
                      <div className="flex items-center justify-between p-4">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <Avatar>
                              <AvatarImage src={friend.avatar} alt={friend.name} />
                              <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                                {friend.name.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white bg-green-500" />
                          </div>
                          <div>
                            <p className="font-medium">{friend.name}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">@{friend.username}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">Online</p>
                          </div>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                            onClick={() => handleCall(friend.id, "audio")}
                          >
                            <Phone className="h-4 w-4" />
                            <span className="sr-only">Call</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                            onClick={() => handleCall(friend.id, "video")}
                          >
                            <Video className="h-4 w-4" />
                            <span className="sr-only">Video Call</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                            onClick={() => handleMessage(friend.id)}
                          >
                            <Mail className="h-4 w-4" />
                            <span className="sr-only">Message</span>
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="col-span-full flex h-40 items-center justify-center rounded-lg border bg-white/50 dark:border-gray-800 dark:bg-gray-900/50">
                <p className="text-gray-500 dark:text-gray-400">No friends are currently online</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="requests" className="mt-4">
          {friendRequests.length > 0 ? (
            <div className="space-y-4">
              {friendRequests.map((request) => (
                <Card key={request.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={request.user.avatar} alt={request.user.name} />
                          <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                            {request.user.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.user.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">@{request.user.username}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">Sent {request.date}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600 dark:border-red-800 dark:hover:bg-red-950/20"
                          onClick={() => handleRejectRequest(request.id)}
                          disabled={isLoading[request.id]}
                        >
                          <X className="mr-1 h-4 w-4" />
                          Decline
                        </Button>
                        <Button
                          size="sm"
                          className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                          onClick={() => handleAcceptRequest(request.id, request.user.id)}
                          disabled={isLoading[request.id]}
                        >
                          <Check className="mr-1 h-4 w-4" />
                          Accept
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="flex h-40 items-center justify-center rounded-lg border bg-white/50 dark:border-gray-800 dark:bg-gray-900/50">
              <p className="text-gray-500 dark:text-gray-400">No pending friend requests</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="suggestions" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {suggestedFriends.map((suggestion) => (
              <Card key={suggestion.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={suggestion.avatar} alt={suggestion.name} />
                        <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                          {suggestion.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{suggestion.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">@{suggestion.username}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {suggestion.mutualFriends} mutual friend{suggestion.mutualFriends !== 1 ? "s" : ""}
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                      onClick={() => handleSendRequest(suggestion.id)}
                      disabled={isLoading[suggestion.id]}
                    >
                      <UserPlus className="mr-1 h-4 w-4" />
                      Add Friend
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

