"use client"

import { Grid, Bookmark, Heart } from "lucide-react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ProfileTabsProps {
  username: string
}

export function ProfileTabs({ username }: ProfileTabsProps) {
  // In a real app, you would fetch these from an API
  const posts = [
    { id: "1", image: "/placeholder.svg?height=300&width=300" },
    { id: "2", image: "/placeholder.svg?height=300&width=300" },
    { id: "3", image: "/placeholder.svg?height=300&width=300" },
    { id: "4", image: "/placeholder.svg?height=300&width=300" },
    { id: "5", image: "/placeholder.svg?height=300&width=300" },
    { id: "6", image: "/placeholder.svg?height=300&width=300" },
  ]

  return (
    <Tabs defaultValue="posts" className="mt-8">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="posts" className="flex items-center gap-2">
          <Grid className="h-4 w-4" />
          <span className="hidden sm:inline">Posts</span>
        </TabsTrigger>
        <TabsTrigger value="saved" className="flex items-center gap-2">
          <Bookmark className="h-4 w-4" />
          <span className="hidden sm:inline">Saved</span>
        </TabsTrigger>
        <TabsTrigger value="liked" className="flex items-center gap-2">
          <Heart className="h-4 w-4" />
          <span className="hidden sm:inline">Liked</span>
        </TabsTrigger>
      </TabsList>
      <TabsContent value="posts" className="mt-6">
        <div className="grid grid-cols-2 gap-1 sm:grid-cols-3 md:gap-2">
          {posts.map((post) => (
            <div key={post.id} className="aspect-square overflow-hidden">
              <img
                src={post.image || "/placeholder.svg"}
                alt={`Post ${post.id}`}
                className="h-full w-full object-cover transition-transform hover:scale-105"
              />
            </div>
          ))}
        </div>
      </TabsContent>
      <TabsContent value="saved" className="mt-6">
        <div className="flex h-40 items-center justify-center">
          <p className="text-gray-500 dark:text-gray-400">No saved posts yet</p>
        </div>
      </TabsContent>
      <TabsContent value="liked" className="mt-6">
        <div className="flex h-40 items-center justify-center">
          <p className="text-gray-500 dark:text-gray-400">No liked posts yet</p>
        </div>
      </TabsContent>
    </Tabs>
  )
}

