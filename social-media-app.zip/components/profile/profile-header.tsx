import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface User {
  id: string
  username: string
  name: string
  bio: string
  avatar: string
  followers: number
  following: number
  posts: number
}

interface ProfileHeaderProps {
  user: User
}

export function ProfileHeader({ user }: ProfileHeaderProps) {
  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-start">
        <Avatar className="h-24 w-24 sm:h-32 sm:w-32">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="flex flex-1 flex-col items-center space-y-4 text-center sm:items-start sm:text-left">
          <div>
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold">{user.name}</h1>
            </div>
            <p className="text-gray-500 dark:text-gray-400">@{user.username}</p>
          </div>
          <p className="max-w-md">{user.bio}</p>
          <div className="flex gap-6">
            <div className="text-center">
              <p className="font-bold">{user.posts}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Posts</p>
            </div>
            <div className="text-center">
              <p className="font-bold">{user.followers.toLocaleString()}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Followers</p>
            </div>
            <div className="text-center">
              <p className="font-bold">{user.following.toLocaleString()}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">Following</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button>Follow</Button>
            <Button variant="outline">Message</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

