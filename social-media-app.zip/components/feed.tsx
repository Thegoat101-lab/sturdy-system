"use client"

import type React from "react"

import { useState } from "react"
import { BookmarkPlus, Heart, MessageCircle, MoreHorizontal, Share2 } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function Feed() {
  const [newPostContent, setNewPostContent] = useState("")

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle post submission logic here
    console.log("New post:", newPostContent)
    setNewPostContent("")
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <form onSubmit={handlePostSubmit}>
            <div className="flex gap-3">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <Textarea
                placeholder="What's on your mind?"
                className="flex-1 resize-none"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
              />
            </div>
            <div className="mt-4 flex justify-end">
              <Button type="submit" disabled={!newPostContent.trim()}>
                Post
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Tabs defaultValue="for-you">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="for-you">For You</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>
        <TabsContent value="for-you" className="mt-4 space-y-4">
          <PostCard
            user={{
              name: "Jane Smith",
              username: "janesmith",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            content="Just launched my new portfolio website! Check it out and let me know what you think. #webdev #portfolio"
            image="/placeholder.svg?height=400&width=600"
            timestamp="2 hours ago"
            likes={42}
            comments={8}
          />
          <PostCard
            user={{
              name: "Alex Johnson",
              username: "alexj",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            content="Beautiful sunset at the beach today. Nature never fails to amaze me. 🌅"
            image="/placeholder.svg?height=400&width=600"
            timestamp="5 hours ago"
            likes={128}
            comments={24}
          />
          <PostCard
            user={{
              name: "Sam Wilson",
              username: "samwilson",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            content="Just finished reading this amazing book on artificial intelligence. Highly recommend it to anyone interested in the field!"
            timestamp="1 day ago"
            likes={56}
            comments={12}
          />
        </TabsContent>
        <TabsContent value="following" className="mt-4 space-y-4">
          <PostCard
            user={{
              name: "Maria Garcia",
              username: "mariagarcia",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            content="Just got back from my trip to Japan! Here are some highlights from Tokyo. Can't wait to go back! 🇯🇵"
            image="/placeholder.svg?height=400&width=600"
            timestamp="3 hours ago"
            likes={87}
            comments={15}
          />
          <PostCard
            user={{
              name: "David Kim",
              username: "davidkim",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            content="Working on a new music project. Stay tuned for updates! 🎵 #music #newproject"
            timestamp="8 hours ago"
            likes={64}
            comments={9}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface PostCardProps {
  user: {
    name: string
    username: string
    avatar: string
  }
  content: string
  image?: string
  timestamp: string
  likes: number
  comments: number
}

function PostCard({ user, content, image, timestamp, likes, comments }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(likes)

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setLiked(!liked)
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center gap-3 space-y-0 p-4">
        <Avatar>
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold leading-none">{user.name}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">@{user.username}</p>
            </div>
            <div className="flex items-center">
              <p className="text-xs text-gray-500 dark:text-gray-400">{timestamp}</p>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="ml-1 h-8 w-8">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">More options</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Report</DropdownMenuItem>
                  <DropdownMenuItem>Mute user</DropdownMenuItem>
                  <DropdownMenuItem>Block user</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="whitespace-pre-wrap">{content}</p>
        {image && (
          <div className="mt-3 overflow-hidden rounded-lg">
            <img src={image || "/placeholder.svg"} alt="Post content" className="w-full object-cover" />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex items-center justify-between p-4 pt-0">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            className={`flex items-center gap-1 ${liked ? "text-red-500" : ""}`}
            onClick={handleLike}
          >
            <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
            <span>{likeCount}</span>
          </Button>
          <Button variant="ghost" size="sm" className="flex items-center gap-1">
            <MessageCircle className="h-4 w-4" />
            <span>{comments}</span>
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Share2 className="h-4 w-4" />
            <span className="sr-only">Share</span>
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <BookmarkPlus className="h-4 w-4" />
            <span className="sr-only">Bookmark</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

