"use client"

import type React from "react"

import { useState } from "react"
import { Send, Paperclip, Smile, Mic, Search, UserPlus, Phone, Video } from "lucide-react"
import { useRouter } from "next/navigation"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddContactDialog } from "@/components/contacts/add-contact-dialog"
import { toast } from "@/hooks/use-toast"

export function ChatInterface() {
  const router = useRouter()
  const [message, setMessage] = useState("")
  const [activeChat, setActiveChat] = useState<string | null>("1")
  const [isAddContactOpen, setIsAddContactOpen] = useState(false)

  const contacts = [
    {
      id: "1",
      name: "Jane Smith",
      avatar: "/placeholder.svg?height=40&width=40",
      lastMessage: "Hey, how are you doing?",
      time: "10:30 AM",
      unread: 2,
    },
    {
      id: "2",
      name: "Alex Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      lastMessage: "Did you see the new video I posted?",
      time: "Yesterday",
      unread: 0,
    },
    {
      id: "3",
      name: "Maria Garcia",
      avatar: "/placeholder.svg?height=40&width=40",
      lastMessage: "Thanks for the recommendation!",
      time: "Yesterday",
      unread: 0,
    },
    {
      id: "4",
      name: "David Kim",
      avatar: "/placeholder.svg?height=40&width=40",
      lastMessage: "Let's catch up this weekend",
      time: "Monday",
      unread: 0,
    },
  ]

  const messages = [
    {
      id: "1",
      senderId: "2", // not the current user
      text: "Hey there! How's it going?",
      time: "10:15 AM",
    },
    {
      id: "2",
      senderId: "current-user", // the current user
      text: "Hi! I'm doing well, thanks for asking. Just finished working on a new video.",
      time: "10:17 AM",
    },
    {
      id: "3",
      senderId: "2",
      text: "That's awesome! What's the video about?",
      time: "10:18 AM",
    },
    {
      id: "4",
      senderId: "current-user",
      text: "It's a tutorial on how to create cool effects for social media videos. I'll send you the link when it's published!",
      time: "10:20 AM",
    },
    {
      id: "5",
      senderId: "2",
      text: "Can't wait to see it! Did you use any special software for the effects?",
      time: "10:25 AM",
    },
    {
      id: "6",
      senderId: "current-user",
      text: "Mostly After Effects and some custom plugins. The results look pretty good!",
      time: "10:28 AM",
    },
    {
      id: "7",
      senderId: "2",
      text: "Hey, how are you doing?",
      time: "10:30 AM",
    },
  ]

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    // In a real app, you would send the message to the server
    console.log("Sending message:", message)

    // Add the message to the UI
    const newMessage = {
      id: `new-${Date.now()}`,
      senderId: "current-user",
      text: message,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    // In a real app, you would update the state with the new message
    toast({
      title: "Message sent",
      description: message,
    })

    setMessage("")
  }

  const handleChatSelect = (contactId: string) => {
    setActiveChat(contactId)
  }

  const handleAddContact = (contact: { name: string; username: string; email: string }) => {
    // In a real app, you would add the contact to the database
    console.log("Adding contact:", contact)
    setIsAddContactOpen(false)

    toast({
      title: "Contact added",
      description: `${contact.name} has been added to your contacts.`,
    })
  }

  const handleCall = (type: "audio" | "video") => {
    if (!activeChat) return

    router.push(`/call/${activeChat}?type=${type}`)
  }

  return (
    <div className="grid h-[calc(100vh-5rem)] grid-cols-1 overflow-hidden rounded-lg border bg-white/80 shadow-xl backdrop-blur-sm dark:border-gray-800 dark:bg-gray-900/80 md:grid-cols-3 lg:grid-cols-4">
      {/* Contacts sidebar */}
      <div className="border-r dark:border-gray-800 md:col-span-1">
        <div className="flex items-center justify-between p-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
            <Input
              type="search"
              placeholder="Search conversations..."
              className="pl-8 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="ml-2 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
            onClick={() => setIsAddContactOpen(true)}
          >
            <UserPlus className="h-5 w-5" />
            <span className="sr-only">Add contact</span>
          </Button>
        </div>
        <Tabs defaultValue="chats">
          <TabsList className="grid w-full grid-cols-2 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
            <TabsTrigger
              value="chats"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
            >
              Chats
            </TabsTrigger>
            <TabsTrigger
              value="calls"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
            >
              Calls
            </TabsTrigger>
          </TabsList>
          <TabsContent value="chats" className="m-0">
            <ScrollArea className="h-[calc(100vh-12rem)]">
              <div className="space-y-1 p-2">
                {contacts.map((contact) => (
                  <button
                    key={contact.id}
                    className={`flex w-full items-center gap-3 rounded-lg p-3 text-left transition-colors ${
                      activeChat === contact.id
                        ? "bg-gradient-to-r from-brand-purple/10 to-brand-pink/10 dark:from-brand-purple/20 dark:to-brand-pink/20"
                        : "hover:bg-gray-50 dark:hover:bg-gray-900"
                    }`}
                    onClick={() => handleChatSelect(contact.id)}
                  >
                    <div className="relative">
                      <Avatar className={activeChat === contact.id ? "ring-2 ring-brand-pink ring-offset-1" : ""}>
                        <AvatarImage src={contact.avatar} alt={contact.name} />
                        <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                          {contact.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      {contact.unread > 0 && (
                        <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-r from-brand-purple to-brand-pink text-xs font-medium text-white">
                          {contact.unread}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 overflow-hidden">
                      <div className="flex items-center justify-between">
                        <p className="font-medium">{contact.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{contact.time}</p>
                      </div>
                      <p className="truncate text-sm text-gray-500 dark:text-gray-400">{contact.lastMessage}</p>
                    </div>
                  </button>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
          <TabsContent value="calls" className="m-0">
            <div className="p-4">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-medium">Recent Calls</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => router.push("/friends")}
                >
                  View All
                </Button>
              </div>

              <div className="space-y-2">
                {contacts.slice(0, 3).map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between rounded-lg p-2 hover:bg-gray-50 dark:hover:bg-gray-900"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={contact.avatar} alt={contact.name} />
                        <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                          {contact.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{contact.name}</p>
                        <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                          <Phone className="h-3 w-3" />
                          <span>Yesterday, 5:30 PM</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                        onClick={() => router.push(`/call/${contact.id}?type=audio`)}
                      >
                        <Phone className="h-4 w-4" />
                        <span className="sr-only">Call</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                        onClick={() => router.push(`/call/${contact.id}?type=video`)}
                      >
                        <Video className="h-4 w-4" />
                        <span className="sr-only">Video Call</span>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <h3 className="mb-2 font-medium">Voicemail</h3>
                <div className="rounded-lg border p-4 dark:border-gray-800">
                  <p className="text-center text-sm text-gray-500 dark:text-gray-400">No voicemail messages</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Chat area */}
      <div className="flex flex-col md:col-span-2 lg:col-span-3">
        {activeChat ? (
          <>
            {/* Chat header */}
            <div className="flex items-center justify-between border-b p-4 dark:border-gray-800">
              <div className="flex items-center gap-3">
                <Avatar className="ring-2 ring-brand-pink ring-offset-1">
                  <AvatarImage
                    src={contacts.find((c) => c.id === activeChat)?.avatar || ""}
                    alt={contacts.find((c) => c.id === activeChat)?.name || ""}
                  />
                  <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                    {contacts.find((c) => c.id === activeChat)?.name.charAt(0) || ""}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{contacts.find((c) => c.id === activeChat)?.name || ""}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Online</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => handleCall("audio")}
                >
                  <Phone className="h-5 w-5" />
                  <span className="sr-only">Voice call</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => handleCall("video")}
                >
                  <Video className="h-5 w-5" />
                  <span className="sr-only">Video call</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                >
                  <Search className="h-5 w-5" />
                  <span className="sr-only">Search in conversation</span>
                </Button>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.senderId === "current-user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[70%] rounded-lg p-3 ${
                        msg.senderId === "current-user"
                          ? "bg-gradient-to-r from-brand-purple to-brand-pink text-white"
                          : "bg-white dark:bg-gray-800"
                      }`}
                    >
                      <p>{msg.text}</p>
                      <p
                        className={`mt-1 text-right text-xs ${
                          msg.senderId === "current-user" ? "text-white/80" : "text-gray-500 dark:text-gray-400"
                        }`}
                      >
                        {msg.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Message input */}
            <div className="border-t p-4 dark:border-gray-800">
              <form onSubmit={handleSendMessage} className="flex items-center gap-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                >
                  <Paperclip className="h-5 w-5" />
                  <span className="sr-only">Attach file</span>
                </Button>
                <Input
                  type="text"
                  placeholder="Type a message..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="flex-1 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                >
                  <Smile className="h-5 w-5" />
                  <span className="sr-only">Add emoji</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => handleCall("audio")}
                >
                  <Mic className="h-5 w-5" />
                  <span className="sr-only">Voice message</span>
                </Button>
                <Button
                  type="submit"
                  size="icon"
                  disabled={!message.trim()}
                  className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                >
                  <Send className="h-5 w-5" />
                  <span className="sr-only">Send message</span>
                </Button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex h-full items-center justify-center">
            <div className="text-center">
              <p className="text-gray-500 dark:text-gray-400">Select a chat to start messaging</p>
            </div>
          </div>
        )}
      </div>

      <AddContactDialog open={isAddContactOpen} onOpenChange={setIsAddContactOpen} onAddContact={handleAddContact} />
    </div>
  )
}

