"use client"

import { useState } from "react"
import { Lock, Play, Crown, Sparkles } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface PremiumContentCardProps {
  content: {
    id: string
    title: string
    type: "video" | "movie" | "post"
    thumbnail: string
    creator: {
      name: string
      username: string
      avatar: string
    }
    duration?: string
    price?: string
    membershipRequired: boolean
    membershipLevel?: "basic" | "premium" | "ultimate"
  }
  isMember: boolean
  membershipLevel?: "basic" | "premium" | "ultimate"
}

export function PremiumContentCard({ content, isMember, membershipLevel }: PremiumContentCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  const hasAccess =
    isMember &&
    (!content.membershipLevel ||
      membershipLevel === "ultimate" ||
      (membershipLevel === "premium" && content.membershipLevel !== "ultimate") ||
      (membershipLevel === "basic" && content.membershipLevel === "basic"))

  const getMembershipIcon = () => {
    switch (content.membershipLevel) {
      case "basic":
        return <Crown className="h-4 w-4 text-blue-500" />
      case "premium":
        return <Crown className="h-4 w-4 text-brand-purple" />
      case "ultimate":
        return <Sparkles className="h-4 w-4 text-brand-pink" />
      default:
        return <Lock className="h-4 w-4" />
    }
  }

  return (
    <Card
      className="overflow-hidden transition-transform hover:scale-[1.02] hover:shadow-xl"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative">
        <img
          src={content.thumbnail || "/placeholder.svg"}
          alt={content.title}
          className="aspect-video w-full object-cover"
        />

        {/* Overlay for premium content */}
        {!hasAccess && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm">
            <Lock className="mb-2 h-8 w-8 text-white" />
            <p className="text-center text-sm font-medium text-white">
              {content.membershipRequired
                ? `${content.membershipLevel?.charAt(0).toUpperCase() + content.membershipLevel?.slice(1) || "Premium"} Members Only`
                : `Pay $${content.price} to Access`}
            </p>
          </div>
        )}

        {/* Play button overlay for videos/movies */}
        {hasAccess && (content.type === "video" || content.type === "movie") && isHovered && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/30 transition-opacity">
            <div className="rounded-full bg-white/20 p-3 backdrop-blur-sm">
              <Play className="h-8 w-8 text-white" fill="white" />
            </div>
          </div>
        )}

        {/* Duration badge for videos/movies */}
        {(content.type === "video" || content.type === "movie") && (
          <div className="absolute bottom-2 right-2 rounded-md bg-black/70 px-2 py-1 text-xs font-medium text-white backdrop-blur-sm">
            {content.duration}
          </div>
        )}

        {/* Premium content badge */}
        <div className="absolute left-2 top-2 flex items-center gap-1 rounded-full bg-black/70 px-2 py-1 text-xs font-medium text-white backdrop-blur-sm">
          {getMembershipIcon()}
          <span>
            {content.membershipLevel?.charAt(0).toUpperCase() + content.membershipLevel?.slice(1) || "Premium"}
          </span>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10 border-2 border-brand-pink">
            <AvatarImage src={content.creator.avatar} alt={content.creator.name} />
            <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
              {content.creator.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <h3 className="truncate font-semibold">{content.title}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">@{content.creator.username}</p>
            <div className="mt-2 flex flex-wrap gap-1">
              <Badge variant="outline" className="text-xs">
                {content.type.charAt(0).toUpperCase() + content.type.slice(1)}
              </Badge>
              {content.price && !content.membershipRequired && (
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-300 dark:hover:bg-green-900/50">
                  ${content.price}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="flex justify-end p-4 pt-0">
        {hasAccess ? (
          <Button
            asChild
            className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
          >
            <Link href={`/content/${content.id}`}>{content.type === "post" ? "View Post" : "Watch Now"}</Link>
          </Button>
        ) : (
          <Button asChild>
            <Link href={content.membershipRequired ? "/membership" : `/content/${content.id}/purchase`}>
              {content.membershipRequired ? "Become a Member" : `Pay $${content.price}`}
            </Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

