"use client"

import { useState } from "react"
import { Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { PremiumContentCard } from "@/components/premium-content/premium-content-card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function PremiumContentFeed() {
  const [contentType, setContentType] = useState<string>("all")
  const [membershipFilter, setMembershipFilter] = useState<string[]>(["basic", "premium", "ultimate"])

  // Mock user membership status - in a real app, this would come from the user's session
  const userMembership = {
    isMember: true,
    level: "premium" as "basic" | "premium" | "ultimate",
  }

  // Mock premium content data
  const premiumContent = [
    {
      id: "1",
      title: "Exclusive Behind-the-Scenes Movie Footage",
      type: "video" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Movie Creator",
        username: "moviecreator",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      duration: "15:24",
      membershipRequired: true,
      membershipLevel: "premium" as const,
    },
    {
      id: "2",
      title: "Full-Length Feature Film: The Adventure",
      type: "movie" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Film Studio",
        username: "filmstudio",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      duration: "1:45:30",
      membershipRequired: true,
      membershipLevel: "ultimate" as const,
    },
    {
      id: "3",
      title: "Exclusive Photo Collection: World Tour",
      type: "post" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Travel Photographer",
        username: "travelphotographer",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      membershipRequired: true,
      membershipLevel: "basic" as const,
    },
    {
      id: "4",
      title: "Tutorial: Advanced Editing Techniques",
      type: "video" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Pro Editor",
        username: "proeditor",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      duration: "42:18",
      price: "4.99",
      membershipRequired: false,
    },
    {
      id: "5",
      title: "Documentary: Ocean Life",
      type: "movie" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Nature Channel",
        username: "naturechannel",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      duration: "58:45",
      membershipRequired: true,
      membershipLevel: "premium" as const,
    },
    {
      id: "6",
      title: "Exclusive Interview with Celebrity",
      type: "video" as const,
      thumbnail: "/placeholder.svg?height=720&width=1280",
      creator: {
        name: "Entertainment News",
        username: "entertainmentnews",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      duration: "22:10",
      membershipRequired: true,
      membershipLevel: "basic" as const,
    },
  ]

  // Filter content based on selected filters
  const filteredContent = premiumContent.filter((content) => {
    // Filter by content type
    if (contentType !== "all" && content.type !== contentType) {
      return false
    }

    // Filter by membership level
    if (content.membershipRequired && !membershipFilter.includes(content.membershipLevel || "")) {
      return false
    }

    return true
  })

  const toggleMembershipFilter = (value: string) => {
    setMembershipFilter((current) =>
      current.includes(value) ? current.filter((item) => item !== value) : [...current, value],
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h1 className="bg-gradient-brand bg-clip-text text-3xl font-bold text-transparent">
          Premium Content
        </h1>
        
        <div className="mt-4 flex items-center gap-2 sm:mt-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span>Filter</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Membership Level</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem
                checked={membershipFilter.includes("basic")}
                onCheckedChange={() => toggleMembershipFilter("basic")}
              >
                Basic
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={membershipFilter.includes("premium")}
                onCheckedChange={() => toggleMembershipFilter("premium")}
              >
                Premium
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem
                checked={membershipFilter.includes("ultimate")}
                onCheckedChange={() => toggleMembershipFilter("ultimate")}
              >
                Ultimate
              </DropdownMenuCheckboxItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Price</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuCheckboxItem checked>
                Membership Included
              </DropdownMenuCheckboxItem>
              <DropdownMenuCheckboxItem checked>
                Pay-per-view
              </DropdownMenuCheckboxItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <Tabs defaultValue="all" onValueChange={setContentType} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger 
            value="all" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            All
          </TabsTrigger>
          <TabsTrigger 
            value="movie" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white\"nk data-[state=active]:text-white"
          >
            Movies
          </TabsTrigger>
          <TabsTrigger 
            value="video" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Videos
          </TabsTrigger>
          <TabsTrigger 
            value="post" 
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Posts
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredContent.map((content) => (
              <PremiumContentCard
                key={content.id}
                content={content}
                isMember={userMembership.isMember}
                membershipLevel={userMembership.level}
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="movie" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredContent
              .filter(content => content.type === "movie")
              .map((content) => (
                <PremiumContentCard
                  key={content.id}
                  content={content}
                  isMember={userMembership.isMember}
                  membershipLevel={userMembership.level}
                />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="video" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredContent
              .filter(content => content.type === "video")
              .map((content) => (
                <PremiumContentCard
                  key={content.id}
                  content={content}
                  isMember={userMembership.isMember}
                  membershipLevel={userMembership.level}
                />
              ))}
          </div>
        </TabsContent>
        
        <TabsContent value="post" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredContent
              .filter(content => content.type === "post")
              .map((content) => (
                <PremiumContentCard
                  key={content.id}
                  content={content}
                  isMember={userMembership.isMember}
                  membershipLevel={userMembership.level}
                />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

