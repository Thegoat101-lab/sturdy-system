"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Bell, BellOff, Home, Menu, MessageSquare, Moon, Plus, Search, Sun, User, UserPlus, Video } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { SideNav } from "@/components/side-nav"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { signOut } from "@/lib/auth-actions"

export function TopNav() {
  const router = useRouter()
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle("dark")
  }

  const toggleNotifications = () => {
    setNotificationsEnabled(!notificationsEnabled)
    // In a real app, you would update the user's notification preferences
  }

  const handleSignOut = async () => {
    await signOut()
    router.push("/sign-in")
    router.refresh()
  }

  // Mock notifications
  const notifications = [
    {
      id: "1",
      type: "live",
      text: "Gamer Girl just went live: 'Playing the new FPS game'",
      time: "2 minutes ago",
      read: false,
      avatar: "/placeholder.svg?height=40&width=40",
      link: "/live/gamergirl",
    },
    {
      id: "2",
      type: "subscription",
      text: "Tech Review posted a new video: 'Latest smartphone review'",
      time: "1 hour ago",
      read: true,
      avatar: "/placeholder.svg?height=40&width=40",
      link: "/profile/techreview",
    },
    {
      id: "3",
      type: "mention",
      text: "Fitness Trainer mentioned you in a comment",
      time: "3 hours ago",
      read: false,
      avatar: "/placeholder.svg?height=40&width=40",
      link: "/profile/fitnesstrainer",
    },
  ]

  return (
    <header className="sticky top-0 z-50 border-b bg-white/80 shadow-sm backdrop-blur-md dark:border-gray-800 dark:bg-gray-950/80">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2 md:gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[240px] sm:w-[300px]">
              <div className="px-1 py-6">
                <SideNav />
              </div>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center gap-2">
            <span className="bg-gradient-brand bg-clip-text text-xl font-bold text-transparent">SocialApp</span>
          </Link>
        </div>
        <div className="hidden flex-1 md:mx-8 md:flex">
          <div className="relative w-full max-w-md">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
            <Input
              type="search"
              placeholder="Search..."
              className="w-full border-purple-200 bg-white/80 pl-8 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
            />
          </div>
        </div>
        <div className="flex items-center gap-1 md:gap-2">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Link href="/">
              <Home className="h-5 w-5" />
              <span className="sr-only">Home</span>
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Link href="/live">
              <Video className="h-5 w-5" />
              <span className="sr-only">Live</span>
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Link href="/messages">
              <MessageSquare className="h-5 w-5" />
              <span className="sr-only">Messages</span>
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Link href="/contacts">
              <UserPlus className="h-5 w-5" />
              <span className="sr-only">Contacts</span>
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            asChild
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            <Link href="/upload">
              <Plus className="h-5 w-5" />
              <span className="sr-only">Create</span>
            </Link>
          </Button>

          {/* Notifications Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="relative text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
              >
                <Bell className="h-5 w-5" />
                {notifications.some((n) => !n.read) && (
                  <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500"></span>
                )}
                <span className="sr-only">Notifications</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[300px]">
              <div className="flex items-center justify-between px-4 py-2">
                <h3 className="font-semibold">Notifications</h3>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleNotifications}>
                  {notificationsEnabled ? (
                    <Bell className="h-4 w-4 text-brand-purple dark:text-brand-pink" />
                  ) : (
                    <BellOff className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <DropdownMenuSeparator />

              {notifications.length === 0 ? (
                <div className="flex flex-col items-center py-6">
                  <Bell className="mb-2 h-8 w-8 text-gray-400" />
                  <p className="text-center text-sm text-gray-500">No notifications yet</p>
                </div>
              ) : (
                <>
                  {notifications.map((notification) => (
                    <DropdownMenuItem key={notification.id} asChild>
                      <Link
                        href={notification.link}
                        className={`flex items-start gap-3 p-3 ${notification.read ? "" : "bg-purple-50 dark:bg-purple-900/20"}`}
                      >
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={notification.avatar} alt="" />
                          <AvatarFallback className="bg-brand-purple text-white dark:bg-brand-pink">
                            {notification.type.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-1">
                          <p className="text-sm">{notification.text}</p>
                          <p className="text-xs text-gray-500">{notification.time}</p>
                        </div>
                        {!notification.read && (
                          <div className="mt-1 h-2 w-2 rounded-full bg-brand-purple dark:bg-brand-pink"></div>
                        )}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/notifications" className="flex w-full justify-center">
                      <span className="text-sm text-brand-purple dark:text-brand-pink">View all notifications</span>
                    </Link>
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="ghost"
            size="icon"
            onClick={toggleDarkMode}
            className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            <span className="sr-only">Toggle theme</span>
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
              >
                <User className="h-5 w-5" />
                <span className="sr-only">Profile</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href="/profile/username">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/subscriptions">My Subscriptions</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/settings">Settings</Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

