"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Mic, MicOff, Phone, Video, VideoOff, MessageSquare, Volume2, VolumeX } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { toast } from "@/hooks/use-toast"

interface CallInterfaceProps {
  friendId: string
  callType: "audio" | "video"
}

export function CallInterface({ friendId, callType }: CallInterfaceProps) {
  const router = useRouter()
  const [callStatus, setCallStatus] = useState<"connecting" | "connected" | "ended">("connecting")
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isSpeakerOff, setIsSpeakerOff] = useState(false)
  const [callDuration, setCallDuration] = useState(0)

  // Mock friend data - in a real app, this would come from your API
  const friend = {
    id: friendId,
    name: "Jane Smith",
    username: "janes",
    avatar: "/placeholder.svg?height=120&width=120",
  }

  useEffect(() => {
    // Simulate call connection
    const connectionTimer = setTimeout(() => {
      setCallStatus("connected")
      toast({
        title: "Call connected",
      })
    }, 2000)

    return () => clearTimeout(connectionTimer)
  }, [])

  useEffect(() => {
    let durationTimer: NodeJS.Timeout

    if (callStatus === "connected") {
      durationTimer = setInterval(() => {
        setCallDuration((prev) => prev + 1)
      }, 1000)
    }

    return () => {
      if (durationTimer) clearInterval(durationTimer)
    }
  }, [callStatus])

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const handleEndCall = () => {
    setCallStatus("ended")
    toast({
      title: "Call ended",
      description: `Call duration: ${formatDuration(callDuration)}`,
    })

    // Redirect back after a short delay
    setTimeout(() => {
      router.push("/friends")
    }, 1500)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
    toast({
      title: isMuted ? "Microphone unmuted" : "Microphone muted",
    })
  }

  const toggleVideo = () => {
    setIsVideoOff(!isVideoOff)
    toast({
      title: isVideoOff ? "Camera turned on" : "Camera turned off",
    })
  }

  const toggleSpeaker = () => {
    setIsSpeakerOff(!isSpeakerOff)
    toast({
      title: isSpeakerOff ? "Speaker turned on" : "Speaker turned off",
    })
  }

  const openChat = () => {
    router.push(`/messages?friend=${friendId}`)
  }

  return (
    <div className="flex h-screen flex-col bg-gradient-to-b from-purple-50 to-pink-50 dark:from-gray-950 dark:to-purple-950">
      <div className="flex flex-1 flex-col items-center justify-center p-4">
        {callType === "video" && !isVideoOff ? (
          <div className="relative mb-8 h-[60vh] w-full max-w-3xl overflow-hidden rounded-xl bg-black">
            {/* This would be a real video stream in a production app */}
            <div className="absolute inset-0 flex items-center justify-center">
              <p className="text-white">Video stream would appear here</p>
            </div>

            {/* Self view */}
            <div className="absolute bottom-4 right-4 h-32 w-48 overflow-hidden rounded-lg bg-gray-800">
              <div className="flex h-full items-center justify-center">
                <p className="text-sm text-white">Your camera</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="mb-8 flex flex-col items-center justify-center">
            <Avatar className="h-32 w-32 ring-4 ring-brand-pink ring-offset-2">
              <AvatarImage src={friend.avatar} alt={friend.name} />
              <AvatarFallback className="text-4xl bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                {friend.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <h2 className="mt-4 text-2xl font-bold">{friend.name}</h2>
            <p className="text-gray-500 dark:text-gray-400">@{friend.username}</p>

            <div className="mt-4 flex items-center gap-2">
              <span
                className={`h-3 w-3 rounded-full ${callStatus === "connected" ? "bg-green-500" : "bg-yellow-500 animate-pulse"}`}
              ></span>
              <span className="text-sm">
                {callStatus === "connecting"
                  ? "Connecting..."
                  : callStatus === "connected"
                    ? `Connected (${formatDuration(callDuration)})`
                    : "Call ended"}
              </span>
            </div>
          </div>
        )}

        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button
            variant="outline"
            size="icon"
            className={`h-14 w-14 rounded-full ${isMuted ? "bg-red-100 text-red-500 dark:bg-red-900/30 dark:text-red-400" : ""}`}
            onClick={toggleMute}
          >
            {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
            <span className="sr-only">{isMuted ? "Unmute" : "Mute"}</span>
          </Button>

          {callType === "video" && (
            <Button
              variant="outline"
              size="icon"
              className={`h-14 w-14 rounded-full ${isVideoOff ? "bg-red-100 text-red-500 dark:bg-red-900/30 dark:text-red-400" : ""}`}
              onClick={toggleVideo}
            >
              {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
              <span className="sr-only">{isVideoOff ? "Turn on camera" : "Turn off camera"}</span>
            </Button>
          )}

          <Button
            variant="outline"
            size="icon"
            className={`h-14 w-14 rounded-full ${isSpeakerOff ? "bg-red-100 text-red-500 dark:bg-red-900/30 dark:text-red-400" : ""}`}
            onClick={toggleSpeaker}
          >
            {isSpeakerOff ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
            <span className="sr-only">{isSpeakerOff ? "Turn on speaker" : "Turn off speaker"}</span>
          </Button>

          <Button variant="outline" size="icon" className="h-14 w-14 rounded-full" onClick={openChat}>
            <MessageSquare className="h-6 w-6" />
            <span className="sr-only">Open chat</span>
          </Button>

          <Button
            variant="destructive"
            size="icon"
            className="h-14 w-14 rounded-full bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700"
            onClick={handleEndCall}
          >
            <Phone className="h-6 w-6 rotate-135" />
            <span className="sr-only">End call</span>
          </Button>
        </div>
      </div>
    </div>
  )
}

