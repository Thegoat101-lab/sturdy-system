"use client"

import { useState } from "react"
import { Search, UserPlus, MoreHorizontal, UserX, UserCheck, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { AddContactDialog } from "@/components/contacts/add-contact-dialog"

export function ContactsManager() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddContactOpen, setIsAddContactOpen] = useState(false)

  // Mock contacts data
  const contacts = [
    {
      id: "1",
      name: "Jane Smith",
      username: "janesmith",
      email: "jane@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Friend",
    },
    {
      id: "2",
      name: "Alex Johnson",
      username: "alexj",
      email: "alex@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Friend",
    },
    {
      id: "3",
      name: "Maria Garcia",
      username: "mariagarcia",
      email: "maria@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Friend",
    },
    {
      id: "4",
      name: "David Kim",
      username: "davidkim",
      email: "david@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Friend",
    },
  ]

  const pendingRequests = [
    {
      id: "5",
      name: "Sarah Williams",
      username: "sarahw",
      email: "sarah@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Pending",
    },
    {
      id: "6",
      name: "Michael Brown",
      username: "michaelb",
      email: "michael@example.com",
      avatar: "/placeholder.svg?height=40&width=40",
      status: "Pending",
    },
  ]

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddContact = (contact: { name: string; username: string; email: string }) => {
    // In a real app, you would add the contact to the database
    console.log("Adding contact:", contact)
    setIsAddContactOpen(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
          <Input
            type="search"
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
          />
        </div>
        <Button
          onClick={() => setIsAddContactOpen(true)}
          className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
        >
          <UserPlus className="mr-2 h-4 w-4" /> Add New Contact
        </Button>
      </div>

      <Tabs defaultValue="all-contacts" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger
            value="all-contacts"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            All Contacts
          </TabsTrigger>
          <TabsTrigger
            value="pending-requests"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Pending Requests {pendingRequests.length > 0 && `(${pendingRequests.length})`}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all-contacts" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              {filteredContacts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <UserX className="mb-4 h-12 w-12 text-gray-400" />
                  <h3 className="mb-2 text-lg font-medium">No contacts found</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {searchQuery ? "Try a different search term" : "Add some contacts to get started"}
                  </p>
                </div>
              ) : (
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center justify-between rounded-lg border border-purple-100 bg-white p-4 shadow-sm transition-all hover:shadow-md dark:border-purple-900 dark:bg-gray-800"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="ring-2 ring-brand-pink ring-offset-1">
                          <AvatarImage src={contact.avatar} alt={contact.name} />
                          <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                            {contact.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{contact.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">@{contact.username}</p>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">More options</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" /> Message
                          </DropdownMenuItem>
                          <DropdownMenuItem>View Profile</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600 dark:text-red-400">
                            <UserX className="mr-2 h-4 w-4" /> Remove Contact
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending-requests" className="mt-6">
          <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
            <CardContent className="p-6">
              {pendingRequests.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <UserCheck className="mb-4 h-12 w-12 text-gray-400" />
                  <h3 className="mb-2 text-lg font-medium">No pending requests</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    You don't have any pending contact requests
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingRequests.map((request) => (
                    <div
                      key={request.id}
                      className="flex items-center justify-between rounded-lg border border-purple-100 bg-white p-4 shadow-sm dark:border-purple-900 dark:bg-gray-800"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={request.avatar} alt={request.name} />
                          <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
                            {request.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{request.name}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">@{request.username}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                        >
                          Accept
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-gray-300 hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800"
                        >
                          Decline
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AddContactDialog open={isAddContactOpen} onOpenChange={setIsAddContactOpen} onAddContact={handleAddContact} />
    </div>
  )
}

