import Link from "next/link"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function TrendingTopics() {
  const trendingTopics = [
    {
      id: 1,
      category: "Technology",
      title: "#ReactJS",
      posts: "12.5k posts",
    },
    {
      id: 2,
      category: "Sports",
      title: "#Olympics2024",
      posts: "45.2k posts",
    },
    {
      id: 3,
      category: "Entertainment",
      title: "#NewMovieRelease",
      posts: "32.1k posts",
    },
    {
      id: 4,
      category: "Business",
      title: "#StartupFunding",
      posts: "8.7k posts",
    },
    {
      id: 5,
      category: "Science",
      title: "#SpaceExploration",
      posts: "15.3k posts",
    },
  ]

  const suggestedUsers = [
    {
      id: 1,
      name: "Tech Insider",
      username: "techinsider",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      name: "Travel Enthusiast",
      username: "travelenthusiast",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 3,
      name: "Food Network",
      username: "foodnetwork",
      avatar: "/placeholder.svg?height=40&width=40",
    },
  ]

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Trending Topics</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          {trendingTopics.map((topic) => (
            <Link
              key={topic.id}
              href={`/trending/${topic.title.substring(1)}`}
              className="block rounded-lg p-2 transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              <div className="text-xs text-gray-500 dark:text-gray-400">{topic.category}</div>
              <div className="font-medium">{topic.title}</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">{topic.posts}</div>
            </Link>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Who to follow</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          {suggestedUsers.map((user) => (
            <div key={user.id} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={user.avatar || "/placeholder.svg"}
                  alt={user.name}
                  className="h-10 w-10 rounded-full object-cover"
                />
                <div>
                  <div className="font-medium">{user.name}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">@{user.username}</div>
                </div>
              </div>
              <button className="rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                Follow
              </button>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

