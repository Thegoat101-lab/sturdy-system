import Link from "next/link"
import {
  Bookmark,
  Compass,
  Home,
  MessageSquare,
  Settings,
  Upload,
  User,
  Users,
  UserPlus,
  Video,
  Bell,
} from "lucide-react"

import { Button } from "@/components/ui/button"

export function SideNav() {
  return (
    <div className="flex flex-col gap-6">
      <nav className="grid gap-1">
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Home className="h-5 w-5" />
            <span>Home</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/live"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Video className="h-5 w-5" />
            <span>Live</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/subscriptions"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Bell className="h-5 w-5" />
            <span>Subscriptions</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/explore"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Compass className="h-5 w-5" />
            <span>Explore</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/messages"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <MessageSquare className="h-5 w-5" />
            <span>Messages</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/contacts"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <UserPlus className="h-5 w-5" />
            <span>Contacts</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/bookmarks"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Bookmark className="h-5 w-5" />
            <span>Bookmarks</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/friends"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Users className="h-5 w-5" />
            <span>Friends</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/profile/username"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <User className="h-5 w-5" />
            <span>Profile</span>
          </Link>
        </Button>
        <Button variant="ghost" asChild className="justify-start">
          <Link
            href="/settings"
            className="flex items-center gap-3 px-3 text-brand-purple hover:text-brand-pink dark:text-brand-pink dark:hover:text-brand-purple"
          >
            <Settings className="h-5 w-5" />
            <span>Settings</span>
          </Link>
        </Button>
      </nav>
      <div className="space-y-2 px-3">
        <Button
          asChild
          className="w-full bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
        >
          <Link href="/upload">
            <Upload className="mr-2 h-4 w-4" />
            Upload Video
          </Link>
        </Button>
        <Button asChild className="w-full bg-red-500 hover:bg-red-600">
          <Link href="/go-live">
            <Video className="mr-2 h-4 w-4" />
            Go Live
          </Link>
        </Button>
      </div>
    </div>
  )
}

