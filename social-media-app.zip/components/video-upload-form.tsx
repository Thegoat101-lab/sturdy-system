"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Upload, X, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { uploadVideo } from "@/lib/video-actions"

export function VideoUploadForm() {
  const router = useRouter()
  const [caption, setCaption] = useState("")
  const [tags, setTags] = useState("")
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check if file is a video
    if (!file.type.startsWith("video/")) {
      setError("Please select a video file")
      return
    }

    setVideoFile(file)
    setError("")

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setPreviewUrl(url)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files?.[0]
    if (!file) return

    // Check if file is a video
    if (!file.type.startsWith("video/")) {
      setError("Please select a video file")
      return
    }

    setVideoFile(file)
    setError("")

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setPreviewUrl(url)
  }

  const clearSelectedFile = () => {
    setVideoFile(null)
    setPreviewUrl(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!videoFile) {
      setError("Please select a video to upload")
      return
    }

    setIsUploading(true)
    setError("")

    try {
      // In a real app, this would upload the video to a storage service
      await uploadVideo(videoFile, caption, tags)
      router.push("/")
      router.refresh()
    } catch (err) {
      setError("Failed to upload video. Please try again.")
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <div className="rounded-md bg-red-50 p-4 text-sm text-red-700 dark:bg-red-900/50 dark:text-red-200">
          {error}
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="video">Upload Video</Label>
        <div
          className={`flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-6 ${
            previewUrl ? "border-primary" : "border-gray-300 dark:border-gray-700"
          }`}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          {previewUrl ? (
            <div className="relative w-full">
              <div className="aspect-[9/16] w-full max-w-md mx-auto overflow-hidden rounded-lg">
                <img
                  src="/placeholder.svg?height=720&width=405"
                  alt="Video preview"
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  <svg className="h-16 w-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <span className="truncate text-sm">{videoFile?.name}</span>
                <Button type="button" variant="ghost" size="sm" onClick={clearSelectedFile}>
                  <X className="h-4 w-4" />
                  <span className="sr-only">Remove file</span>
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-2 text-center">
              <Upload className="h-10 w-10 text-gray-400" />
              <div className="space-y-1">
                <p className="text-sm font-medium">Drag and drop your video here</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">MP4, MOV, or WebM up to 100MB</p>
              </div>
              <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                Select file
              </Button>
              <input
                ref={fileInputRef}
                id="video"
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleFileChange}
              />
            </div>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="caption">Caption</Label>
        <Textarea
          id="caption"
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Write a caption for your video..."
          rows={3}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="tags">Tags</Label>
        <Input
          id="tags"
          value={tags}
          onChange={(e) => setTags(e.target.value)}
          placeholder="Add tags separated by spaces (e.g. #dance #funny #travel)"
        />
      </div>

      <Button type="submit" className="w-full" disabled={isUploading || !videoFile}>
        {isUploading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading...
          </>
        ) : (
          "Upload Video"
        )}
      </Button>
    </form>
  )
}

