"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { VideoFeed } from "@/components/video-feed"
import { TrendingTopics } from "@/components/trending-topics"
import { Button } from "@/components/ui/button"
import { Sparkles } from "lucide-react"

export function PersonalizedFeed() {
  const [activeTab, setActiveTab] = useState("for-you")
  const [userInterests, setUserInterests] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(true)

  // Mock interests - in a real app, these would come from user data
  const availableInterests = [
    "Gaming",
    "Music",
    "Sports",
    "Technology",
    "Fashion",
    "Travel",
    "Cooking",
    "Fitness",
    "Art",
    "Movies",
  ]

  useEffect(() => {
    // Simulate loading user interests from API
    const loadUserInterests = async () => {
      setIsLoading(true)
      // In a real app, fetch from API
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock data - in a real app, this would come from your API
      const savedInterests = ["Gaming", "Technology", "Fitness"]
      setUserInterests(savedInterests)
      setIsLoading(false)
    }

    loadUserInterests()
  }, [])

  const toggleInterest = (interest: string) => {
    if (userInterests.includes(interest)) {
      setUserInterests(userInterests.filter((i) => i !== interest))
    } else {
      setUserInterests([...userInterests, interest])
    }
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="for-you" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between">
          <TabsList className="bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
            <TabsTrigger
              value="for-you"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
            >
              For You
            </TabsTrigger>
            <TabsTrigger
              value="following"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
            >
              Following
            </TabsTrigger>
            <TabsTrigger
              value="trending"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
            >
              Trending
            </TabsTrigger>
          </TabsList>

          {activeTab === "for-you" && (
            <Button
              variant="outline"
              size="sm"
              className="text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
              onClick={() => document.getElementById("interests-section")?.scrollIntoView({ behavior: "smooth" })}
            >
              <Sparkles className="mr-1 h-4 w-4" />
              Customize
            </Button>
          )}
        </div>

        <TabsContent value="for-you" className="mt-4">
          <VideoFeed filter="personalized" interests={userInterests} />
        </TabsContent>

        <TabsContent value="following" className="mt-4">
          <VideoFeed filter="following" />
        </TabsContent>

        <TabsContent value="trending" className="mt-4">
          <TrendingTopics />
          <div className="mt-4">
            <VideoFeed filter="trending" />
          </div>
        </TabsContent>
      </Tabs>

      {activeTab === "for-you" && (
        <div
          id="interests-section"
          className="mt-8 rounded-lg border bg-white/80 p-4 backdrop-blur-sm dark:border-gray-800 dark:bg-gray-900/80"
        >
          <h3 className="mb-4 text-lg font-medium">Customize Your Feed</h3>
          <p className="mb-4 text-sm text-gray-600 dark:text-gray-400">
            Select topics you're interested in to personalize your feed
          </p>

          <div className="flex flex-wrap gap-2">
            {availableInterests.map((interest) => (
              <Button
                key={interest}
                variant={userInterests.includes(interest) ? "default" : "outline"}
                size="sm"
                className={
                  userInterests.includes(interest)
                    ? "bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                    : ""
                }
                onClick={() => toggleInterest(interest)}
              >
                {interest}
              </Button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

