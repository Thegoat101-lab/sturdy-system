import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function SuggestedUsers() {
  const suggestedUsers = [
    {
      id: "1",
      name: "Tech Insider",
      username: "techinsider",
      avatar: "/placeholder.svg?height=40&width=40",
      followers: "1.2M",
    },
    {
      id: "2",
      name: "Travel Enthusiast",
      username: "travelenthusiast",
      avatar: "/placeholder.svg?height=40&width=40",
      followers: "845K",
    },
    {
      id: "3",
      name: "Food Network",
      username: "foodnetwork",
      avatar: "/placeholder.svg?height=40&width=40",
      followers: "3.5M",
    },
    {
      id: "4",
      name: "Fitness Coach",
      username: "fitnesscoach",
      avatar: "/placeholder.svg?height=40&width=40",
      followers: "567K",
    },
    {
      id: "5",
      name: "Music Artist",
      username: "musicartist",
      avatar: "/placeholder.svg?height=40&width=40",
      followers: "2.1M",
    },
  ]

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Suggested for you</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          {suggestedUsers.map((user) => (
            <div key={user.id} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <img
                  src={user.avatar || "/placeholder.svg"}
                  alt={user.name}
                  className="h-10 w-10 rounded-full object-cover"
                />
                <div>
                  <div className="font-medium">{user.name}</div>
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    <span>@{user.username}</span>
                    <span className="mx-1">•</span>
                    <span>{user.followers} followers</span>
                  </div>
                </div>
              </div>
              <Button variant="outline" size="sm" className="rounded-full">
                Follow
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

