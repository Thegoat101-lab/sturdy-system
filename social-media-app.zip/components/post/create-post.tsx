"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Image, Video, Link2, Lock, Loader2, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { createPost } from "@/lib/post-actions"

export function CreatePost() {
  const router = useRouter()
  const [content, setContent] = useState("")
  const [isPremium, setIsPremium] = useState(false)
  const [mediaType, setMediaType] = useState<"none" | "image" | "video">("none")
  const [mediaFile, setMediaFile] = useState<File | null>(null)
  const [mediaPreview, setMediaPreview] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleMediaSelect = (type: "image" | "video") => {
    setMediaType(type)
    if (fileInputRef.current) {
      fileInputRef.current.accept = type === "image" ? "image/*" : "video/*"
      fileInputRef.current.click()
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check if file type matches selected media type
    if (
      (mediaType === "image" && !file.type.startsWith("image/")) ||
      (mediaType === "video" && !file.type.startsWith("video/"))
    ) {
      return
    }

    setMediaFile(file)

    // Create a preview URL
    const url = URL.createObjectURL(file)
    setMediaPreview(url)
  }

  const clearMedia = () => {
    setMediaFile(null)
    setMediaPreview(null)
    setMediaType("none")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim() && !mediaFile) return

    setIsSubmitting(true)

    try {
      // In a real app, this would upload the media and create the post
      await createPost({
        content,
        mediaFile,
        mediaType,
        isPremium,
      })

      // Reset form
      setContent("")
      setMediaFile(null)
      setMediaPreview(null)
      setMediaType("none")
      setIsPremium(false)

      // Refresh the feed
      router.refresh()
    } catch (error) {
      console.error("Failed to create post:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
      <CardContent className="p-4">
        <form onSubmit={handleSubmit}>
          <div className="flex gap-3">
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-4">
              <Textarea
                placeholder="What's on your mind?"
                className="min-h-[100px] resize-none border-purple-200 bg-white/80 backdrop-blur-sm dark:border-purple-900 dark:bg-gray-900/80"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />

              {mediaPreview && (
                <div className="relative rounded-lg border border-gray-200 dark:border-gray-800">
                  {mediaType === "image" ? (
                    <img
                      src={mediaPreview || "/placeholder.svg"}
                      alt="Preview"
                      className="max-h-[300px] w-full rounded-lg object-contain"
                    />
                  ) : (
                    <div className="aspect-video w-full max-w-md mx-auto overflow-hidden rounded-lg bg-black">
                      <img
                        src="/placeholder.svg?height=720&width=405"
                        alt="Video preview"
                        className="h-full w-full object-cover"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                        <svg className="h-16 w-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>
                  )}
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-2 h-8 w-8 rounded-full bg-black/50 text-white hover:bg-black/70"
                    onClick={clearMedia}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove media</span>
                  </Button>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="flex items-center gap-1 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => handleMediaSelect("image")}
                >
                  <Image className="h-4 w-4" />
                  <span>Photo</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="flex items-center gap-1 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                  onClick={() => handleMediaSelect("video")}
                >
                  <Video className="h-4 w-4" />
                  <span>Video</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="flex items-center gap-1 text-brand-purple hover:bg-brand-purple/10 dark:text-brand-pink dark:hover:bg-brand-pink/10"
                >
                  <Link2 className="h-4 w-4" />
                  <span>Link</span>
                </Button>

                <div className="ml-auto flex items-center gap-2">
                  <div className="flex items-center space-x-2">
                    <Switch id="premium-content" checked={isPremium} onCheckedChange={setIsPremium} />
                    <Label htmlFor="premium-content" className="flex items-center gap-1 text-sm">
                      <Lock
                        className={`h-4 w-4 ${isPremium ? "text-brand-purple dark:text-brand-pink" : "text-gray-500"}`}
                      />
                      Premium Content
                    </Label>
                  </div>
                </div>
              </div>

              {isPremium && (
                <div className="rounded-lg bg-purple-50 p-3 dark:bg-purple-900/20">
                  <h4 className="mb-2 font-medium text-brand-purple dark:text-brand-pink">Premium Content Settings</h4>
                  <RadioGroup defaultValue="members-only">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="members-only" id="members-only" />
                      <Label htmlFor="members-only">Members Only</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="pay-per-view" id="pay-per-view" />
                      <Label htmlFor="pay-per-view">Pay-per-view</Label>
                    </div>
                  </RadioGroup>
                </div>
              )}

              <div className="flex justify-end">
                <Button
                  type="submit"
                  className="bg-gradient-to-r from-brand-purple to-brand-pink hover:from-brand-pink hover:to-brand-purple"
                  disabled={isSubmitting || (!content.trim() && !mediaFile)}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Posting...
                    </>
                  ) : (
                    "Post"
                  )}
                </Button>
              </div>
            </div>
          </div>
          <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileChange} />
        </form>
      </CardContent>
    </Card>
  )
}

