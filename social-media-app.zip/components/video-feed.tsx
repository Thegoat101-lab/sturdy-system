"use client"

import { useState, useRef } from "react"
import { Heart, MessageCircle, Share2, Bookmark } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function VideoFeed() {
  return (
    <div className="space-y-4">
      <Tabs defaultValue="for-you" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/50 backdrop-blur-sm dark:bg-gray-900/50">
          <TabsTrigger
            value="for-you"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            For You
          </TabsTrigger>
          <TabsTrigger
            value="following"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-brand-purple data-[state=active]:to-brand-pink data-[state=active]:text-white"
          >
            Following
          </TabsTrigger>
        </TabsList>
        <TabsContent value="for-you" className="mt-4 space-y-4">
          <VideoPost
            user={{
              name: "Jane Smith",
              username: "janesmith",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            caption="Check out this amazing sunset! #sunset #vibes"
            videoSrc="/placeholder.svg?height=720&width=405"
            likes={1245}
            comments={86}
          />
          <VideoPost
            user={{
              name: "Alex Johnson",
              username: "alexj",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            caption="New dance challenge! Who's in? 💃 #dancechallenge"
            videoSrc="/placeholder.svg?height=720&width=405"
            likes={8732}
            comments={342}
          />
          <VideoPost
            user={{
              name: "Sam Wilson",
              username: "samwilson",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            caption="My morning routine 🌞 #morningroutine #productivity"
            videoSrc="/placeholder.svg?height=720&width=405"
            likes={3421}
            comments={128}
          />
        </TabsContent>
        <TabsContent value="following" className="mt-4 space-y-4">
          <VideoPost
            user={{
              name: "Maria Garcia",
              username: "mariagarcia",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            caption="Tokyo adventures 🇯🇵 #japan #travel"
            videoSrc="/placeholder.svg?height=720&width=405"
            likes={5621}
            comments={231}
          />
          <VideoPost
            user={{
              name: "David Kim",
              username: "davidkim",
              avatar: "/placeholder.svg?height=40&width=40",
            }}
            caption="New song preview! Full track drops Friday 🎵 #newmusic"
            videoSrc="/placeholder.svg?height=720&width=405"
            likes={7845}
            comments={412}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface VideoPostProps {
  user: {
    name: string
    username: string
    avatar: string
  }
  caption: string
  videoSrc: string
  likes: number
  comments: number
}

function VideoPost({ user, caption, videoSrc, likes, comments }: VideoPostProps) {
  const [liked, setLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(likes)
  const [isPlaying, setIsPlaying] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setLiked(!liked)
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  // In a real app, you would use an actual video file
  // For this example, we'll use an image as a placeholder
  return (
    <div className="relative overflow-hidden rounded-lg bg-black shadow-xl">
      <div className="aspect-[9/16] w-full max-w-md mx-auto">
        {/* This would be a video in a real app */}
        <div className="h-full w-full cursor-pointer" onClick={togglePlayPause}>
          <img src={videoSrc || "/placeholder.svg"} alt="Video thumbnail" className="h-full w-full object-cover" />
          {/* Overlay play button */}
          {!isPlaying && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="rounded-full bg-gradient-to-r from-brand-purple to-brand-pink p-4">
                <svg className="h-12 w-12 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User info and caption */}
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
        <div className="flex items-center gap-3">
          <Avatar className="ring-2 ring-brand-pink ring-offset-2">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback className="bg-gradient-to-r from-brand-purple to-brand-pink text-white">
              {user.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold">{user.name}</p>
            <p className="text-sm text-gray-300">@{user.username}</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="ml-auto rounded-full border-white bg-white/10 text-white backdrop-blur-sm hover:bg-white/20 hover:text-white"
          >
            Follow
          </Button>
        </div>
        <p className="mt-2">{caption}</p>
      </div>

      {/* Interaction buttons */}
      <div className="absolute bottom-24 right-4 flex flex-col items-center gap-6">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/20 backdrop-blur-sm hover:bg-gradient-to-r hover:from-brand-purple hover:to-brand-pink"
          onClick={handleLike}
        >
          <Heart className={`h-6 w-6 ${liked ? "fill-brand-pink text-brand-pink" : "text-white"}`} />
          <span className="mt-1 text-xs text-white">{likeCount}</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/20 text-white backdrop-blur-sm hover:bg-gradient-to-r hover:from-brand-purple hover:to-brand-pink"
        >
          <MessageCircle className="h-6 w-6" />
          <span className="mt-1 text-xs">{comments}</span>
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/20 text-white backdrop-blur-sm hover:bg-gradient-to-r hover:from-brand-purple hover:to-brand-pink"
        >
          <Share2 className="h-6 w-6" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/20 text-white backdrop-blur-sm hover:bg-gradient-to-r hover:from-brand-purple hover:to-brand-pink"
        >
          <Bookmark className="h-6 w-6" />
        </Button>
      </div>
    </div>
  )
}

